import { AnalysisResult } from '../types/incident';

export function generateIncidentReportMarkdown(result: AnalysisResult): string {
  const divider = '='.repeat(78);
  const subDivider = '-'.repeat(78);

  const affectedServicesStr = result.affectedServices.length > 0
    ? result.affectedServices.join(', ')
    : 'None identified';

  const evidenceSection = result.confirmedEvidence.length > 0
    ? result.confirmedEvidence
        .map((ev, i) => {
          const points = ev.dataPoints.map((p) => `    * ${p}`).join('\n');
          return `  [${ev.id}] ${ev.category}
  Description: ${ev.description}
  Log Extract: "${ev.rawExtract.trim()}"
  Data Points:
${points}`;
        })
        .join('\n\n')
    : '  No confirmed error evidence detected in observation timeframe.';

  const hypothesesSection = result.possibleRootCauses.length > 0
    ? result.possibleRootCauses
        .map((hyp) => {
          const valSteps = hyp.validationSteps.map((v) => `    [ ] ${v}`).join('\n');
          return `  [${hyp.id}] ${hyp.hypothesis} (Likelihood: ${hyp.likelihood.toUpperCase()})
  Rationale: ${hyp.rationale}
  Validation Tests:
${valSteps}`;
        })
        .join('\n\n')
    : '  No active failure hypotheses; system operating within operational envelope.';

  const stepsSection = result.troubleshootingSteps.length > 0
    ? result.troubleshootingSteps
        .map(
          (s) =>
            `  Step ${s.stepNumber} [${s.priority}] - ${s.title}\n  Action: ${s.action}\n  Expected Outcome: ${s.expectedOutcome}`
        )
        .join('\n\n')
    : '  No immediate troubleshooting actions required.';

  const errorsSection = result.repeatedErrors.length > 0
    ? result.repeatedErrors
        .map(
          (e, idx) =>
            `  ${idx + 1}. [Count: ${e.count}] ${e.signature}
     Services: ${e.affectedServices.join(', ') || 'N/A'}
     First Seen: ${e.firstSeen || 'N/A'} | Last Seen: ${e.lastSeen || 'N/A'}
     Sample: "${e.sampleMessage}"`
        )
        .join('\n\n')
    : '  Zero repeated error clusters detected.';

  const checklistStr = result.escalation.escalationChecklist
    .map((item) => `  [ ] ${item}`)
    .join('\n');

  return `${divider}
AI INCIDENT ANALYZER - FINTECH TECHOPS INCIDENT REPORT
${divider}
Incident ID:       ${result.incidentId}
Title:             ${result.incidentTitle}
Severity:          [${result.severity.toUpperCase()}]
Generated At:      ${result.generatedAt}
Analysis Engine:   ${result.modeLabel}
Affected Services: ${affectedServicesStr}
Time Window:       ${result.timeWindow.start || 'N/A'} to ${result.timeWindow.end || 'N/A'} (Duration: ${result.timeWindow.duration || 'N/A'})
Telemetry Stats:   ${result.totalLinesParsed} lines parsed | ${result.errorCount} errors | ${result.warningCount} warnings

${subDivider}
1. SEVERITY & OPERATIONAL RATIONALE
${subDivider}
Severity Level: ${result.severity}
Rationale:
${result.severityReason}

Executive Summary:
${result.summary}

${subDivider}
2. CONFIRMED EVIDENCE (DIRECT OBSERVATIONS IN LOGS - NO ASSUMPTIONS)
${subDivider}
${evidenceSection}

${subDivider}
3. POSSIBLE ROOT CAUSES (HYPOTHESES REQUIRING VALIDATION)
${subDivider}
${hypothesesSection}

${subDivider}
4. REPEATED ERRORS & IMPACTED SERVICES
${subDivider}
${errorsSection}

${subDivider}
5. PRIORITIZED TROUBLESHOOTING & CONTAINMENT PLAN
${subDivider}
${stepsSection}

${subDivider}
6. ESCALATION GUIDANCE & TIER HANDOFF
${subDivider}
Escalate to:        ${result.escalation.targetTier} (${result.escalation.shouldEscalate ? 'ESCALATION REQUIRED' : 'NO IMMEDIATE ESCALATION'})
SLA Response Time:  ${result.escalation.slaResponseTime}
Designated Team:    ${result.escalation.onCallTeam}
Trigger Condition:  ${result.escalation.triggerCondition}

Escalation Checklist:
${checklistStr}

${divider}
CONFIDENTIAL - FINTECH TECHOPS & RELIABILITY ENGINEERING USE ONLY
Simulated Incident Telemetry. No direct production database execution.
${divider}`;
}

export function downloadTextFile(filename: string, content: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadJsonFile(filename: string, data: any) {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
