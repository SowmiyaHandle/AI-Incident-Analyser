import React, { useState, useEffect } from 'react';
import { AnalysisResult } from './types/incident';
import { SAMPLE_SCENARIOS } from './data/sampleScenarios';
import { Header } from './components/Header';
import { LogInputPanel } from './components/LogInputPanel';
import { IncidentOverview } from './components/IncidentOverview';
import { EvidenceVsHypotheses } from './components/EvidenceVsHypotheses';
import { RepeatedErrorsTable } from './components/RepeatedErrorsTable';
import { TroubleshootingAndEscalation } from './components/TroubleshootingAndEscalation';
import { ReportActionBar } from './components/ReportActionBar';
import { AboutModal } from './components/AboutModal';
import {
  AlertCircle,
  FileCode,
  SlidersHorizontal,
  Search,
  ExternalLink,
  Shield,
  Activity,
  Terminal,
} from 'lucide-react';

export default function App() {
  const [logs, setLogs] = useState<string>(SAMPLE_SCENARIOS[0].logs);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [serverError, setServerError] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [geminiConnected, setGeminiConnected] = useState<boolean>(false);
  const [aboutOpen, setAboutOpen] = useState<boolean>(false);
  const [activeView, setActiveView] = useState<'dashboard' | 'rawLogs'>('dashboard');
  const [logFilter, setLogFilter] = useState<'ALL' | 'ERROR' | 'WARN' | 'INFO'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Check health on mount
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        if (data.status === 'ok') {
          setGeminiConnected(!!data.geminiConfigured);
        }
      })
      .catch((err) => {
        console.warn('Backend health check warning:', err);
      });
  }, []);

  const handleAnalyze = async (forceRuleBased?: boolean) => {
    if (!logs.trim()) {
      setValidationError('Please paste or upload logs before running incident analysis.');
      return;
    }

    setServerError(null);
    setValidationError(null);
    setIsAnalyzing(true);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          logs,
          forceRuleBased: !!forceRuleBased,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || `Server responded with status ${response.status}`);
      }

      setResult(data as AnalysisResult);
      setActiveView('dashboard');
    } catch (err: any) {
      console.error('Analysis request error:', err);
      setServerError(
        err.message || 'Failed to complete incident analysis. Please check server logs.'
      );
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setLogs('');
    setResult(null);
    setServerError(null);
    setValidationError(null);
  };

  // Filter raw logs for the inspector view
  const rawLogLines = logs.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const filteredLogLines = rawLogLines.filter((line) => {
    if (logFilter === 'ERROR' && !/\b(ERROR|FATAL|CRITICAL|Exception)\b/i.test(line)) {
      return false;
    }
    if (logFilter === 'WARN' && !/\b(WARN|WARNING)\b/i.test(line)) {
      return false;
    }
    if (logFilter === 'INFO' && !/\b(INFO)\b/i.test(line)) {
      return false;
    }
    if (searchQuery && !line.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-white">
      {/* Top Navigation */}
      <Header
        onOpenAbout={() => setAboutOpen(true)}
        onReset={handleReset}
        geminiConnected={geminiConnected}
        hasResult={!!result}
      />

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Server or Global Error Alert */}
        {serverError && (
          <div className="p-4 rounded-xl bg-rose-950/50 border border-rose-800/80 text-rose-200 text-xs flex items-start gap-3 shadow-lg">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold text-sm">Analysis Pipeline Error</p>
              <p className="text-rose-300/90">{serverError}</p>
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => handleAnalyze(true)}
                  className="font-semibold underline hover:text-white"
                >
                  Click here to retry with the Deterministic Rule-Based Engine
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Case Study Context Banner */}
        <section className="bg-indigo-950/30 border border-indigo-900/50 rounded-xl p-4 text-xs text-slate-300">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 mb-2 border-b border-indigo-900/40">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Fintech Case Study
              </span>
              <h2 className="text-sm font-bold text-white">
                Payment Authorization &amp; Auth Token Triage (P1–P4 Incidents)
              </h2>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">
              Simulated Telemetry Triage
            </span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            In fintech payment gateways, transaction authorization relies on cryptographic token verification (RS256 JWTs), 3DSecure cardholder challenges, and distributed OAuth session caches. Incidents range from P1 systemic key expiry blackouts and P2 distributed cache scope desyncs, to P3 pre-auth hold mismatches and P4 deprecation warnings. Investigate telemetry logs to isolate confirmed evidence from hypotheses and triage across P1 Containment, P2 Diagnostics, P3 Remediation, and P4 Prevention tiers.
          </p>
        </section>

        {/* Input Panel */}
        <section aria-label="Log Input and Sample Scenarios">
          <LogInputPanel
            logs={logs}
            setLogs={setLogs}
            onAnalyze={handleAnalyze}
            isAnalyzing={isAnalyzing}
            geminiConnected={geminiConnected}
            validationError={validationError}
            setValidationError={setValidationError}
          />
        </section>

        {/* Analysis Results View */}
        {result && (
          <section className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            {/* View Switcher Bar */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveView('dashboard')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
                    activeView === 'dashboard'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800'
                  }`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  Incident Triage Dashboard
                </button>

                <button
                  type="button"
                  onClick={() => setActiveView('rawLogs')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
                    activeView === 'rawLogs'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800'
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  Raw Log Inspector ({rawLogLines.length})
                </button>
              </div>

              <div className="text-xs text-slate-500 hidden sm:block font-mono">
                Engine: {result.modeLabel.split('(')[0].trim()}
              </div>
            </div>

            {activeView === 'dashboard' ? (
              <div className="space-y-6">
                {/* 1. Incident Overview, Severity & KPIs */}
                <IncidentOverview result={result} />

                {/* 2. Action Bar: Copy & Download Incident Reports */}
                <ReportActionBar result={result} />

                {/* 3. Confirmed Evidence vs Possible Root Causes (Core Separation) */}
                <EvidenceVsHypotheses
                  confirmedEvidence={result.confirmedEvidence}
                  possibleRootCauses={result.possibleRootCauses}
                />

                {/* 4. Repeated Errors & Impacted Services Table */}
                <RepeatedErrorsTable repeatedErrors={result.repeatedErrors} />

                {/* 5. Prioritized Troubleshooting Plan & Escalation Criteria */}
                <TroubleshootingAndEscalation
                  steps={result.troubleshootingSteps}
                  escalation={result.escalation}
                />
              </div>
            ) : (
              /* Raw Log Inspector View */
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Filter Level:
                    </span>
                    {(['ALL', 'ERROR', 'WARN', 'INFO'] as const).map((lvl) => (
                      <button
                        key={lvl}
                        type="button"
                        onClick={() => setLogFilter(lvl)}
                        className={`text-xs px-2.5 py-1 rounded font-mono font-semibold transition border ${
                          logFilter === lvl
                            ? 'bg-indigo-950 text-indigo-300 border-indigo-700'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                        }`}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>

                  {/* Search box */}
                  <div className="relative w-full sm:w-64">
                    <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search log entries..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="max-h-[500px] overflow-y-auto space-y-1 font-mono text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
                  {filteredLogLines.length === 0 ? (
                    <div className="text-center text-slate-500 py-8">
                      No matching log entries found for current filter.
                    </div>
                  ) : (
                    filteredLogLines.map((line, idx) => {
                      const isErr = /\b(ERROR|FATAL|CRITICAL|Exception)\b/i.test(line);
                      const isWarn = /\b(WARN|WARNING)\b/i.test(line);
                      return (
                        <div
                          key={idx}
                          className={`p-1.5 rounded flex items-start gap-2 hover:bg-slate-900 transition ${
                            isErr
                              ? 'text-rose-300 bg-rose-950/20'
                              : isWarn
                              ? 'text-amber-300 bg-amber-950/20'
                              : 'text-slate-300'
                          }`}
                        >
                          <span className="text-slate-600 select-none w-8 text-right shrink-0">
                            {idx + 1}
                          </span>
                          <span className="break-all whitespace-pre-wrap">{line}</span>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-4 px-4 sm:px-6 lg:px-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-indigo-400" />
            <span>AI Incident Analyzer • Simulated Fintech Operations Triage</span>
          </div>
          <div className="text-[11px] text-slate-600">
            Read-only analytical advisor • No live clearinghouse mutation or automated command execution
          </div>
        </div>
      </footer>

      {/* About & Technical Architecture Modal */}
      <AboutModal isOpen={aboutOpen} onClose={() => setAboutOpen(false)} />
    </div>
  );
}
