export type SeverityLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export interface RepeatedError {
  signature: string;
  count: number;
  sampleMessage: string;
  firstSeen?: string;
  lastSeen?: string;
  affectedServices: string[];
}

export interface ConfirmedEvidence {
  id: string;
  category: string;
  description: string;
  rawExtract: string;
  sourceLine?: number;
  dataPoints: string[];
}

export interface PossibleRootCause {
  id: string;
  hypothesis: string;
  likelihood: 'High' | 'Medium' | 'Low';
  rationale: string;
  validationSteps: string[];
}

export type IncidentPriority = 'P1' | 'P2' | 'P3' | 'P4';

export interface TroubleshootingStep {
  stepNumber: number;
  priority: 'P1' | 'P2' | 'P3' | 'P4';
  title: string;
  action: string;
  expectedOutcome: string;
}

export interface EscalationGuidance {
  shouldEscalate: boolean;
  targetTier: 'L1' | 'L2' | 'L3' | 'None';
  triggerCondition: string;
  onCallTeam: string;
  slaResponseTime: string;
  escalationChecklist: string[];
}

export interface AnalysisResult {
  analysisMode: 'gemini-ai' | 'rule-based';
  modeLabel: string;
  incidentId: string;
  incidentTitle: string;
  generatedAt: string;
  severity: SeverityLevel;
  severityReason: string;
  summary: string;
  totalLinesParsed: number;
  errorCount: number;
  warningCount: number;
  affectedServices: string[];
  timeWindow: {
    start?: string;
    end?: string;
    duration?: string;
  };
  repeatedErrors: RepeatedError[];
  confirmedEvidence: ConfirmedEvidence[];
  possibleRootCauses: PossibleRootCause[];
  troubleshootingSteps: TroubleshootingStep[];
  escalation: EscalationGuidance;
}

export interface ScenarioPreset {
  id: string;
  name: string;
  shortDesc: string;
  expectedSeverity: SeverityLevel;
  icon: string;
  logs: string;
}
