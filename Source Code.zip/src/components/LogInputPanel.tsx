import React, { useState, useRef, DragEvent } from 'react';
import { SAMPLE_SCENARIOS } from '../data/sampleScenarios';
import {
  Upload,
  FileText,
  Trash2,
  Play,
  Sparkles,
  Cpu,
  AlertCircle,
  CreditCard,
  Database,
  AlertTriangle,
  ShieldAlert,
  Loader2,
} from 'lucide-react';

interface LogInputPanelProps {
  logs: string;
  setLogs: (val: string) => void;
  onAnalyze: (forceRuleBased?: boolean) => void;
  isAnalyzing: boolean;
  geminiConnected: boolean;
  validationError: string | null;
  setValidationError: (err: string | null) => void;
}

export const LogInputPanel: React.FC<LogInputPanelProps> = ({
  logs,
  setLogs,
  onAnalyze,
  isAnalyzing,
  geminiConnected,
  validationError,
  setValidationError,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedScenarioId, setSelectedScenarioId] = useState<string | null>(null);
  const [selectedMode, setSelectedMode] = useState<'ai' | 'rule'>('ai');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const lineCount = logs.trim() ? logs.split(/\r?\n/).length : 0;
  const byteCount = new Blob([logs]).size;
  const formattedSize = byteCount > 1024 * 1024
    ? `${(byteCount / (1024 * 1024)).toFixed(2)} MB`
    : byteCount > 1024
    ? `${(byteCount / 1024).toFixed(1)} KB`
    : `${byteCount} bytes`;

  const handleScenarioSelect = (scenarioId: string) => {
    const scenario = SAMPLE_SCENARIOS.find((s) => s.id === scenarioId);
    if (scenario) {
      setLogs(scenario.logs);
      setSelectedScenarioId(scenario.id);
      setValidationError(null);
    }
  };

  const handleFileUpload = (file: File) => {
    const validExtensions = ['.txt', '.log'];
    const hasValidExt = validExtensions.some((ext) =>
      file.name.toLowerCase().endsWith(ext)
    );

    if (!hasValidExt) {
      setValidationError(
        `Invalid file type "${file.name}". Please upload a valid .txt or .log file.`
      );
      return;
    }

    if (file.size === 0) {
      setValidationError('Uploaded file is empty (0 bytes). Please select a file containing log data.');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setValidationError('File size exceeds 5MB limit. Please provide a targeted log segment.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text || text.trim().length === 0) {
        setValidationError('File contains no text or whitespace only.');
        return;
      }
      setLogs(text);
      setSelectedScenarioId(null);
      setValidationError(null);
    };
    reader.onerror = () => {
      setValidationError('Failed to read log file. Please try pasting the contents directly.');
    };
    reader.readAsText(file);
  };

  const onDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleRunAnalysis = () => {
    if (!logs.trim()) {
      setValidationError('Log stream is empty. Please paste logs, upload a file, or pick a sample scenario.');
      return;
    }
    setValidationError(null);
    onAnalyze(selectedMode === 'rule');
  };

  const getScenarioIcon = (iconName: string) => {
    switch (iconName) {
      case 'AlertOctagon':
        return <AlertCircle className="w-4 h-4 text-rose-400" />;
      case 'CreditCard':
        return <CreditCard className="w-4 h-4 text-indigo-400" />;
      case 'Database':
        return <Database className="w-4 h-4 text-amber-400" />;
      case 'AlertTriangle':
        return <AlertTriangle className="w-4 h-4 text-orange-400" />;
      case 'AlertCircle':
        return <AlertCircle className="w-4 h-4 text-emerald-400" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-4 h-4 text-blue-400" />;
      default:
        return <FileText className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-5">
      {/* Sample Scenario Preset Selector */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <span>Case Study Scenarios</span>
            <span className="text-[10px] font-normal text-slate-500 lowercase">(simulated sample logs)</span>
          </label>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {SAMPLE_SCENARIOS.map((sc) => {
            const isSelected = selectedScenarioId === sc.id;
            return (
              <button
                key={sc.id}
                type="button"
                onClick={() => handleScenarioSelect(sc.id)}
                className={`flex flex-col text-left p-3 rounded-lg border transition-all ${
                  isSelected
                    ? 'bg-indigo-950/70 border-indigo-500/80 ring-1 ring-indigo-500/50'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="flex items-center gap-2">
                    {getScenarioIcon(sc.icon)}
                    <span className="text-xs font-semibold text-slate-200">{sc.name}</span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      sc.expectedSeverity === 'Critical'
                        ? 'bg-rose-950/60 text-rose-300 border border-rose-800/40'
                        : sc.expectedSeverity === 'Medium'
                        ? 'bg-amber-950/60 text-amber-300 border border-amber-800/40'
                        : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40'
                    }`}
                  >
                    {sc.expectedSeverity}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {sc.shortDesc}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Textarea and Upload Drop Zone */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold text-slate-300 flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-400" />
            Application Log Stream
          </span>
          <div className="flex items-center gap-3 text-[11px]">
            <span>
              Lines: <strong className="text-slate-200">{lineCount}</strong>
            </span>
            <span>
              Size: <strong className="text-slate-200">{formattedSize}</strong>
            </span>
            {logs && (
              <button
                type="button"
                onClick={() => {
                  setLogs('');
                  setSelectedScenarioId(null);
                  setValidationError(null);
                }}
                className="text-slate-400 hover:text-rose-400 transition flex items-center gap-1 font-medium"
                title="Clear logs"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear
              </button>
            )}
          </div>
        </div>

        <div
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onDrop={onDrop}
          className={`relative rounded-lg border transition-all ${
            isDragging
              ? 'border-indigo-400 bg-indigo-950/30 ring-2 ring-indigo-500/40'
              : 'border-slate-800 bg-slate-950/80 focus-within:border-indigo-500/70 focus-within:ring-1 focus-within:ring-indigo-500/30'
          }`}
        >
          <textarea
            value={logs}
            onChange={(e) => {
              setLogs(e.target.value);
              setSelectedScenarioId(null);
              if (validationError) setValidationError(null);
            }}
            placeholder="Paste application logs here, or drag & drop a .log / .txt file...

Simulated Sample Logs Example:
10:15:20 INFO Payment request received | txn_id=TXN1001
10:15:21 INFO Gateway response received | txn_id=TXN1001 | status=SUCCESS
10:15:21 INFO Gateway reference created | txn_id=TXN1001 | ref=GW5001
10:15:22 ERROR Merchant callback failed | txn_id=TXN1001 | error=TIMEOUT
10:15:27 WARN Merchant payment status remains PENDING | txn_id=TXN1001"
            rows={8}
            className="w-full bg-transparent p-3.5 font-mono text-xs text-slate-200 placeholder-slate-600 focus:outline-none resize-y leading-relaxed"
          />

          {isDragging && (
            <div className="absolute inset-0 bg-slate-950/90 rounded-lg flex flex-col items-center justify-center pointer-events-none border-2 border-dashed border-indigo-400">
              <Upload className="w-8 h-8 text-indigo-400 animate-bounce mb-2" />
              <p className="text-sm font-semibold text-slate-200">Drop your .log or .txt file here</p>
              <p className="text-xs text-slate-400">Will be loaded instantly for analysis</p>
            </div>
          )}
        </div>

        {/* Upload file bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleFileUpload(e.target.files[0]);
                }
              }}
              accept=".log,.txt,text/plain"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 transition"
            >
              <Upload className="w-3.5 h-3.5 text-indigo-400" />
              Upload .txt / .log file
            </button>
            <span className="text-[11px] text-slate-500">
              Plain text or formatted logs up to 5MB
            </span>
          </div>

          {/* Engine Selector */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              type="button"
              onClick={() => setSelectedMode('ai')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition ${
                selectedMode === 'ai'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              AI Mode (Gemini)
            </button>
            <button
              type="button"
              onClick={() => setSelectedMode('rule')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition ${
                selectedMode === 'rule'
                  ? 'bg-slate-700 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              Rule-Based Mode
            </button>
          </div>
        </div>
      </div>

      {/* Validation Error Message */}
      {validationError && (
        <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800/60 flex items-start gap-2.5 text-rose-200 text-xs">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Analysis Pre-flight Warning</p>
            <p className="text-rose-300/90 mt-0.5">{validationError}</p>
          </div>
        </div>
      )}

      {/* Action / Analyze Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-800">
        <div className="text-xs text-slate-400">
          {selectedMode === 'ai' ? (
            geminiConnected ? (
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Gemini 3.8 Flash model primed for root-cause synthesis
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-amber-400">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                No Gemini API key detected in env; will gracefully use Rule-Based Engine
              </span>
            )
          ) : (
            <span className="flex items-center gap-1.5 text-slate-300">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              Deterministic regex & clustering parser active (zero LLM calls)
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={handleRunAnalysis}
          disabled={isAnalyzing}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg bg-gradient-to-r from-indigo-500 via-indigo-600 to-cyan-600 hover:from-indigo-400 hover:via-indigo-500 hover:to-cyan-500 text-white font-semibold text-xs tracking-wide shadow-lg shadow-indigo-600/30 disabled:opacity-60 disabled:cursor-not-allowed transition-all"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Analyzing Log Records...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-white" />
              <span>Analyze Incident Logs</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
