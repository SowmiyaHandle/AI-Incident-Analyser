import React from 'react';
import { SeverityLevel } from '../types/incident';
import { AlertOctagon, AlertTriangle, AlertCircle, Info } from 'lucide-react';

interface SeverityBadgeProps {
  severity: SeverityLevel;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const SeverityBadge: React.FC<SeverityBadgeProps> = ({
  severity,
  size = 'md',
  showIcon = true,
}) => {
  const configs: Record<
    SeverityLevel,
    {
      label: string;
      bg: string;
      text: string;
      border: string;
      ring: string;
      icon: React.ReactNode;
      description: string;
    }
  > = {
    Critical: {
      label: 'CRITICAL',
      bg: 'bg-rose-500/15',
      text: 'text-rose-400',
      border: 'border-rose-500/30',
      ring: 'ring-rose-500/20',
      icon: <AlertOctagon className={size === 'lg' ? 'w-5 h-5' : size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4'} />,
      description: 'Customer payment block, ledger inconsistency, or critical transaction stoppage.',
    },
    High: {
      label: 'HIGH',
      bg: 'bg-orange-500/15',
      text: 'text-orange-400',
      border: 'border-orange-500/30',
      ring: 'ring-orange-500/20',
      icon: <AlertTriangle className={size === 'lg' ? 'w-5 h-5' : size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4'} />,
      description: 'Major service degradation, multiple cascading errors, or elevated failure rates.',
    },
    Medium: {
      label: 'MEDIUM',
      bg: 'bg-amber-500/15',
      text: 'text-amber-300',
      border: 'border-amber-500/30',
      ring: 'ring-amber-500/20',
      icon: <AlertCircle className={size === 'lg' ? 'w-5 h-5' : size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4'} />,
      description: 'Isolated component errors or latency threshold warnings with automated mitigation.',
    },
    Low: {
      label: 'LOW',
      bg: 'bg-emerald-500/15',
      text: 'text-emerald-400',
      border: 'border-emerald-500/30',
      ring: 'ring-emerald-500/20',
      icon: <Info className={size === 'lg' ? 'w-5 h-5' : size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4'} />,
      description: 'Non-impacting warning, informational telemetry, or cached fallback working as designed.',
    },
  };

  const config = configs[severity] || configs.Low;

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs font-semibold gap-1.5',
    md: 'px-3 py-1 text-xs tracking-wider font-bold gap-2',
    lg: 'px-4 py-1.5 text-sm tracking-wider font-extrabold gap-2.5',
  }[size];

  return (
    <span
      title={config.description}
      className={`inline-flex items-center rounded-md border font-mono uppercase transition-all shadow-sm ${config.bg} ${config.text} ${config.border} ${sizeClasses}`}
    >
      {showIcon && config.icon}
      <span>{config.label}</span>
    </span>
  );
};
