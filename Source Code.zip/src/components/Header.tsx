import React from 'react';
import { Activity, ShieldCheck, Sparkles, BookOpen, RefreshCw, Cpu } from 'lucide-react';

interface HeaderProps {
  onOpenAbout: () => void;
  onReset: () => void;
  geminiConnected: boolean;
  hasResult: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenAbout,
  onReset,
  geminiConnected,
  hasResult,
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 via-indigo-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 text-white font-black text-xl tracking-wider">
            <Activity className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-slate-100 tracking-tight">
                AI Incident Analyzer
              </h1>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide bg-indigo-950/80 text-indigo-300 border border-indigo-700/50">
                <ShieldCheck className="w-3 h-3 text-indigo-400" />
                FINTECH TECHOPS
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Case Study: <strong className="text-indigo-300 font-medium">Payment Successful, but Merchant Confirmation Missing</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* AI / Rule-based indicator */}
          <div
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs border font-medium ${
              geminiConnected
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/60'
                : 'bg-amber-950/40 text-amber-300 border-amber-800/60'
            }`}
            title={
              geminiConnected
                ? 'Connected to Google Gemini 3.8 Flash API'
                : 'Rule-Based Engine Active (Gemini API key not attached or offline)'
            }
          >
            {geminiConnected ? (
              <>
                <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-spin-slow" />
                <span>Gemini 3.8 Flash AI</span>
              </>
            ) : (
              <>
                <Cpu className="w-3.5 h-3.5 text-amber-400" />
                <span>Rule-Based Engine</span>
              </>
            )}
          </div>

          {hasResult && (
            <button
              onClick={onReset}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition"
              title="Reset analysis and paste new logs"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Analysis</span>
            </button>
          )}

          <button
            onClick={onOpenAbout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-200 bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-700/60 transition shadow-sm hover:shadow"
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
            <span>About Architecture</span>
          </button>
        </div>
      </div>
    </header>
  );
};
