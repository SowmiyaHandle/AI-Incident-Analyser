import React, { useState } from 'react';
import { TroubleshootingStep, EscalationGuidance } from '../types/incident';
import {
  ListOrdered,
  AlertCircle,
  Clock,
  Users,
  CheckSquare,
  Square,
  ArrowUpRight,
  ShieldAlert,
} from 'lucide-react';

interface TroubleshootingAndEscalationProps {
  steps: TroubleshootingStep[];
  escalation: EscalationGuidance;
}

export const TroubleshootingAndEscalation: React.FC<TroubleshootingAndEscalationProps> = ({
  steps,
  escalation,
}) => {
  const [completedItems, setCompletedItems] = useState<Record<number, boolean>>({});

  const toggleCheck = (idx: number) => {
    setCompletedItems((prev) => ({
      ...prev,
      [idx]: !prev[idx],
    }));
  };

  const getPriorityBadge = (priority: 'P1' | 'P2' | 'P3' | 'P4') => {
    switch (priority) {
      case 'P1':
        return (
          <span className="font-mono text-[10px] font-extrabold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 uppercase">
            P1 Containment
          </span>
        );
      case 'P2':
        return (
          <span className="font-mono text-[10px] font-extrabold px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 border border-orange-500/40 uppercase">
            P2 Diagnostic
          </span>
        );
      case 'P3':
        return (
          <span className="font-mono text-[10px] font-extrabold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase">
            P3 Remediation
          </span>
        );
      case 'P4':
        return (
          <span className="font-mono text-[10px] font-extrabold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase">
            P4 Prevention
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
      {/* 2 COLS: PRIORITIZED ACTION PLAN */}
      <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-indigo-950 text-indigo-400 flex items-center justify-center border border-indigo-800/50">
              <ListOrdered className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">
                Prioritized Troubleshooting & Containment Steps
              </h3>
              <p className="text-[11px] text-slate-400">
                Ordered by urgency: containment first to halt customer impact, followed by isolation
              </p>
            </div>
          </div>
          <span className="font-mono text-xs font-bold text-slate-400">
            {steps.length} Steps
          </span>
        </div>

        <div className="space-y-3">
          {steps.map((s) => (
            <div
              key={s.stepNumber}
              className="bg-slate-950/70 border border-slate-800/80 rounded-lg p-3.5 space-y-2 hover:border-slate-700 transition"
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-800 text-indigo-300 font-mono font-bold text-xs flex items-center justify-center border border-slate-700">
                    {s.stepNumber}
                  </span>
                  <span className="font-bold text-slate-100">{s.title}</span>
                </div>
                {getPriorityBadge(s.priority)}
              </div>

              <div className="text-xs text-slate-300 bg-slate-900/90 p-2.5 rounded border border-slate-800 font-mono leading-relaxed">
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  Action to Take:
                </span>
                {s.action}
              </div>

              <div className="text-[11px] text-emerald-400/90 flex items-start gap-1.5 pt-0.5">
                <span className="font-bold">Target Outcome:</span>
                <span>{s.expectedOutcome}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 1 COL: ESCALATION CRITERIA & HANDOFF */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div
                className={`w-7 h-7 rounded-md flex items-center justify-center border ${
                  escalation.shouldEscalate
                    ? 'bg-rose-950 text-rose-400 border-rose-800/50'
                    : 'bg-emerald-950 text-emerald-400 border-emerald-800/50'
                }`}
              >
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100">
                  Tier Escalation Policy
                </h3>
                <p className="text-[11px] text-slate-400">
                  L1 Triage → L2 SRE → L3 Core Arch
                </p>
              </div>
            </div>
            <span
              className={`font-mono text-xs font-black px-2 py-0.5 rounded border ${
                escalation.targetTier === 'L3'
                  ? 'bg-rose-950/80 text-rose-300 border-rose-700/60'
                  : escalation.targetTier === 'L2'
                  ? 'bg-orange-950/80 text-orange-300 border-orange-700/60'
                  : 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60'
              }`}
            >
              {escalation.targetTier}
            </span>
          </div>

          {/* Trigger Condition Callout */}
          <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-lg space-y-2">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-indigo-400" />
              Trigger Condition:
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {escalation.triggerCondition}
            </p>
          </div>

          {/* SLA & On-Call Team */}
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded bg-slate-950/40 border border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                SLA Response Time:
              </span>
              <span className="font-mono font-bold text-slate-200">
                {escalation.slaResponseTime}
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded bg-slate-950/40 border border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-indigo-400" />
                Target On-Call Team:
              </span>
              <span className="font-medium text-slate-200 text-right text-[11px]">
                {escalation.onCallTeam}
              </span>
            </div>
          </div>

          {/* Interactive Checklist */}
          <div className="space-y-1.5 pt-1">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Escalation Protocol Checklist:</span>
              <span className="text-[10px] text-slate-500 font-normal">click to check off</span>
            </div>
            <div className="space-y-1.5">
              {escalation.escalationChecklist.map((item, idx) => {
                const isChecked = !!completedItems[idx];
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => toggleCheck(idx)}
                    className={`w-full text-left flex items-start gap-2 p-2 rounded text-xs transition border ${
                      isChecked
                        ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300'
                        : 'bg-slate-950/50 border-slate-800/80 text-slate-300 hover:bg-slate-800/40'
                    }`}
                  >
                    {isChecked ? (
                      <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                    )}
                    <span className={isChecked ? 'line-through opacity-80' : ''}>
                      {item}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Escalation Bridge: OpsGenie / PagerDuty</span>
          <span className="flex items-center gap-1 text-indigo-400 hover:underline cursor-pointer">
            View Runbook <ArrowUpRight className="w-3 h-3" />
          </span>
        </div>
      </div>
    </div>
  );
};
