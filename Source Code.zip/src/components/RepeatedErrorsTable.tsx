import React, { useState } from 'react';
import { RepeatedError } from '../types/incident';
import { Layers, ChevronDown, ChevronUp, Terminal, AlertTriangle } from 'lucide-react';

interface RepeatedErrorsTableProps {
  repeatedErrors: RepeatedError[];
}

export const RepeatedErrorsTable: React.FC<RepeatedErrorsTableProps> = ({ repeatedErrors }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  if (repeatedErrors.length === 0) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg text-center text-xs text-slate-400">
        <Layers className="w-8 h-8 text-slate-600 mx-auto mb-2" />
        <p className="font-semibold text-slate-300">No Repeated Error Signatures</p>
        <p className="text-slate-500 mt-1">Zero recurring error patterns were identified in the telemetry logs.</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-indigo-950 text-indigo-400 flex items-center justify-center border border-indigo-800/50">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
              Repeated Error Signatures & Impacted Services
            </h3>
            <p className="text-[11px] text-slate-400">
              Clustered by normalized pattern; timestamps and blast radius per signature
            </p>
          </div>
        </div>
        <span className="font-mono text-xs font-bold text-indigo-400 px-2 py-0.5 rounded bg-indigo-950/60 border border-indigo-800/40">
          {repeatedErrors.length} Unique Signatures
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300 border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-[11px] font-semibold uppercase tracking-wider text-slate-400 bg-slate-950/50">
              <th className="py-2.5 px-3 w-16 text-center">Count</th>
              <th className="py-2.5 px-3">Error Signature Pattern</th>
              <th className="py-2.5 px-3 w-48">Affected Services</th>
              <th className="py-2.5 px-3 w-40">Time Window</th>
              <th className="py-2.5 px-3 w-16 text-center">Details</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {repeatedErrors.map((err, idx) => {
              const isExpanded = expandedIndex === idx;
              return (
                <React.Fragment key={idx}>
                  <tr
                    onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                    className="hover:bg-slate-800/40 cursor-pointer transition"
                  >
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-flex items-center justify-center font-mono font-extrabold text-xs px-2.5 py-0.5 rounded-full border ${
                          err.count >= 10
                            ? 'bg-rose-950/70 text-rose-300 border-rose-700/60'
                            : err.count >= 4
                            ? 'bg-orange-950/70 text-orange-300 border-orange-700/60'
                            : 'bg-indigo-950/70 text-indigo-300 border-indigo-700/60'
                        }`}
                      >
                        {err.count}×
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-[11px] text-slate-200">
                      <div className="line-clamp-2">{err.signature}</div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex flex-wrap gap-1">
                        {err.affectedServices && err.affectedServices.length > 0 ? (
                          err.affectedServices.map((svc) => (
                            <span
                              key={svc}
                              className="font-mono text-[10px] bg-slate-800 text-indigo-300 px-1.5 py-0.5 rounded border border-slate-700/80"
                            >
                              {svc}
                            </span>
                          ))
                        ) : (
                          <span className="text-slate-500 text-[11px]">unspecified</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-[11px] text-slate-400 font-mono">
                      <div>First: {err.firstSeen || 'N/A'}</div>
                      <div>Last:  {err.lastSeen || 'N/A'}</div>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        aria-label="Toggle details"
                        className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition"
                      >
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </button>
                    </td>
                  </tr>

                  {isExpanded && (
                    <tr className="bg-slate-950/80">
                      <td colSpan={5} className="p-3.5 space-y-2 border-b border-slate-800/80">
                        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-300">
                          <Terminal className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Exact Representative Log Message:</span>
                        </div>
                        <div className="bg-slate-900 border border-slate-800 rounded p-2.5 font-mono text-xs text-rose-300/90 whitespace-pre-wrap break-all leading-relaxed">
                          {err.sampleMessage}
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400">
                          <AlertTriangle className="w-3 h-3 text-amber-400" />
                          <span>
                            Clustered using tokenized identifiers (UUIDs, transaction IDs, memory addresses replaced with tokens)
                          </span>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
