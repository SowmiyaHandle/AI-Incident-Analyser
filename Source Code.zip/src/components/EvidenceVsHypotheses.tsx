import React from 'react';
import { ConfirmedEvidence, PossibleRootCause } from '../types/incident';
import {
  CheckCircle2,
  HelpCircle,
  Terminal,
  ShieldCheck,
  Search,
  AlertCircle,
  FileCheck2,
} from 'lucide-react';

interface EvidenceVsHypothesesProps {
  confirmedEvidence: ConfirmedEvidence[];
  possibleRootCauses: PossibleRootCause[];
}

export const EvidenceVsHypotheses: React.FC<EvidenceVsHypothesesProps> = ({
  confirmedEvidence,
  possibleRootCauses,
}) => {
  return (
    <div className="space-y-4">
      {/* SRE Principle Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3 text-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong className="text-white">Strict Fact-Hypothesis Separation:</strong> SRE protocol strictly separates observable log data from operational theories to prevent confirmation bias during active outages.
          </span>
        </div>
        <span className="hidden sm:inline-block text-[11px] font-mono text-slate-400 border border-slate-700/80 px-2 py-0.5 rounded bg-slate-800/60">
          RFC 9110 / SRE Standard
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* COLUMN 1: CONFIRMED EVIDENCE */}
        <div className="bg-slate-900 border border-emerald-900/40 rounded-xl p-5 shadow-lg flex flex-col h-full">
          <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-emerald-900/30">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-md bg-emerald-950 text-emerald-400 flex items-center justify-center border border-emerald-800/50">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                  Confirmed Evidence
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                    Observed Facts
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400">
                  Explicitly verified log records, error codes, and telemetry metrics
                </p>
              </div>
            </div>
            <span className="font-mono text-xs font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/40">
              {confirmedEvidence.length} Verified
            </span>
          </div>

          <div className="space-y-3.5 flex-1">
            {confirmedEvidence.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 bg-slate-950/40 rounded-lg border border-slate-800/60">
                <FileCheck2 className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p>No confirmed error signatures identified in the provided log sample.</p>
              </div>
            ) : (
              confirmedEvidence.map((ev) => (
                <div
                  key={ev.id}
                  className="bg-slate-950/70 border border-slate-800/80 hover:border-emerald-800/40 rounded-lg p-3.5 space-y-2 transition-all"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200 flex items-center gap-1.5">
                      <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-slate-800 text-emerald-300 border border-slate-700">
                        {ev.id}
                      </span>
                      {ev.category}
                    </span>
                    <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                      Verified
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {ev.description}
                  </p>

                  {/* Raw Log Extract Box */}
                  <div className="bg-slate-900 border border-slate-800 rounded p-2 font-mono text-[11px] text-emerald-300/90 overflow-x-auto flex items-start gap-2">
                    <Terminal className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                    <code className="whitespace-pre-wrap break-all">{ev.rawExtract}</code>
                  </div>

                  {/* Bulleted Data Points */}
                  <div className="space-y-1 pt-1">
                    <div className="text-[10px] uppercase tracking-wider font-semibold text-slate-400">
                      Direct Telemetry Data Points:
                    </div>
                    <ul className="space-y-1 text-xs text-slate-300">
                      {ev.dataPoints.map((point, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-emerald-400 font-bold shrink-0">•</span>
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* COLUMN 2: POSSIBLE ROOT CAUSES (HYPOTHESES) */}
        <div className="bg-slate-900 border border-amber-900/40 rounded-xl p-5 shadow-lg flex flex-col h-full">
          <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-amber-900/30">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-md bg-amber-950 text-amber-400 flex items-center justify-center border border-amber-800/50">
                <HelpCircle className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                  Possible Root Causes
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30">
                    Hypotheses
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400">
                  Engineering theories requiring targeted validation before remediation
                </p>
              </div>
            </div>
            <span className="font-mono text-xs font-bold text-amber-400 px-2 py-0.5 rounded bg-amber-950/60 border border-amber-800/40">
              {possibleRootCauses.length} Hypotheses
            </span>
          </div>

          <div className="space-y-3.5 flex-1">
            {possibleRootCauses.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 bg-slate-950/40 rounded-lg border border-slate-800/60">
                <Search className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p>No active failure hypotheses detected for this telemetry window.</p>
              </div>
            ) : (
              possibleRootCauses.map((hyp) => (
                <div
                  key={hyp.id}
                  className="bg-slate-950/70 border border-slate-800/80 hover:border-amber-800/40 rounded-lg p-3.5 space-y-2.5 transition-all"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-slate-800 text-amber-300 border border-slate-700">
                      {hyp.id}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${
                        hyp.likelihood === 'High'
                          ? 'bg-rose-950/60 text-rose-300 border-rose-800/50'
                          : hyp.likelihood === 'Medium'
                          ? 'bg-amber-950/60 text-amber-300 border-amber-800/50'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                    >
                      Likelihood: {hyp.likelihood}
                    </span>
                  </div>

                  <div className="text-xs font-semibold text-slate-100">
                    {hyp.hypothesis}
                  </div>

                  <div className="text-xs text-slate-300 bg-slate-900/80 p-2.5 rounded border border-slate-800/80">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
                      Technical Rationale:
                    </span>
                    {hyp.rationale}
                  </div>

                  {/* Concrete Validation Checklist */}
                  <div className="space-y-1.5 pt-1">
                    <div className="text-[10px] uppercase tracking-wider font-semibold text-amber-400/90 flex items-center gap-1">
                      <Search className="w-3 h-3" />
                      Validation Tests to Confirm / Disprove:
                    </div>
                    <ul className="space-y-1 text-xs text-slate-300">
                      {hyp.validationSteps.map((step, idx) => (
                        <li key={idx} className="flex items-start gap-2 bg-slate-900/40 p-1.5 rounded border border-slate-800/50">
                          <span className="text-amber-400 font-bold shrink-0">→</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
