import React, { useState } from 'react';
import {
  X,
  Layers,
  ShieldAlert,
  Server,
  Cpu,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  BookOpen,
  Code2,
  Check,
} from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'assumptions' | 'limitations' | 'testing'>('architecture');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center text-white shadow-md">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                About AI Incident Analyzer
              </h2>
              <p className="text-xs text-slate-400">
                Fintech Technology Operations Architecture, Assumptions & Safety Protocol
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-5 gap-4">
          <button
            type="button"
            onClick={() => setActiveTab('architecture')}
            className={`py-3 text-xs font-semibold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'architecture'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            System Architecture
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('assumptions')}
            className={`py-3 text-xs font-semibold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'assumptions'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Core Assumptions
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('limitations')}
            className={`py-3 text-xs font-semibold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'limitations'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            Limitations & Guardrails
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('testing')}
            className={`py-3 text-xs font-semibold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'testing'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            Testing & Verification
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300 leading-relaxed">
          {activeTab === 'architecture' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  Case Study Focus: Payment Authorization &amp; Auth Token Triage (P1–P4)
                </h4>
                <p>
                  This incident analyzer is tailored for fintech Technology Operations and SRE teams responsible for the payment authorization perimeter. Inbound card checkouts and API requests undergo cryptographic token validation (<code className="text-emerald-300 font-mono">RS256 JWTs</code>), 3DSecure issuer authentication, and distributed OAuth session cache verification. Telemetry triage is categorized across <strong className="text-indigo-300">P1 (Critical)</strong>, <strong className="text-orange-300">P2 (High)</strong>, <strong className="text-amber-300">P3 (Medium)</strong>, and <strong className="text-emerald-300">P4 (Low)</strong> operational tiers.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div className="p-3.5 rounded-lg bg-slate-950/50 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-slate-200 flex items-center gap-1.5">
                    <Server className="w-4 h-4 text-emerald-400" />
                    Express Backend Gateway &amp; Proxy
                  </div>
                  <p className="text-slate-400">
                    Runs on Node.js/Express. Securely isolates the Gemini API key on the server side. Enforces tokenization and structured JSON Schema validation for both AI models and deterministic rules with strict P1–P4 action mapping.
                  </p>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-950/50 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-slate-200 flex items-center gap-1.5">
                    <Cpu className="w-4 h-4 text-amber-400" />
                    Deterministic Rule-Based Triage Engine
                  </div>
                  <p className="text-slate-400">
                    Parses authorization identifiers (<code className="text-indigo-300 font-mono">auth_id</code>, <code className="text-indigo-300 font-mono">token_id</code>, <code className="text-indigo-300 font-mono">auth_code</code>), detects cryptographic key expirations and circuit breaker state changes, and validates token cache scope parity.
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-indigo-950/20 border border-indigo-900/40 text-indigo-200">
                <strong className="text-indigo-100 block mb-1">Strict Fact-Hypothesis Separation Protocol:</strong>
                SRE protocol strictly separates observable log data from operational theories. Direct facts (HTTP 401/403 status codes, circuit breaker state, key IDs, cache node latency) are held distinct from hypotheses (replication lag, clock skew, expired truststore). Assumptions are never presented as facts.
              </div>
            </div>
          )}

          {activeTab === 'assumptions' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-indigo-400" />
                  Authorization Incident Taxonomy (P1 to P4)
                </h4>
                <p>
                  Fintech operations mandate disciplined categorization so responders can triage without ambiguity:
                </p>
              </div>

              <div className="space-y-2.5">
                <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-rose-950 text-rose-300 font-bold flex items-center justify-center shrink-0 mt-0.5 border border-rose-800/50 text-[11px]">P1</span>
                  <div>
                    <strong className="text-rose-300">P1 Critical Outage &amp; Containment:</strong>
                    <p className="text-slate-400 mt-0.5">
                      Global authorization blackouts, signing key expiry, circuit breaker trips, or 100% checkout stoppage. Immediate containment action: hot-swap KMS/HSM signing keys and hold retry loops to prevent double debits.
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-orange-950 text-orange-300 font-bold flex items-center justify-center shrink-0 mt-0.5 border border-orange-800/50 text-[11px]">P2</span>
                  <div>
                    <strong className="text-orange-300">P2 High Degradation &amp; Diagnostics:</strong>
                    <p className="text-slate-400 mt-0.5">
                      Distributed token cache desynchronization, scope drift (HTTP 403 Forbidden surges e.g. &gt;30%), or degraded partner switches. Containment action: drain desynced replica nodes and trace replication offset deltas.
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-amber-950 text-amber-300 font-bold flex items-center justify-center shrink-0 mt-0.5 border border-amber-800/50 text-[11px]">P3</span>
                  <div>
                    <strong className="text-amber-300">P3 Medium Operational Asynchrony &amp; Remediation:</strong>
                    <p className="text-slate-400 mt-0.5">
                      Pre-authorization hold approved on customer card line, but post-auth settlement capture was rejected as stale or unmatched. Customer credit line is blocked; safe remediation validates auth codes before re-dispatching.
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-emerald-950 text-emerald-300 font-bold flex items-center justify-center shrink-0 mt-0.5 border border-emerald-800/50 text-[11px]">P4</span>
                  <div>
                    <strong className="text-emerald-300">P4 Low Telemetry Warning &amp; Prevention:</strong>
                    <p className="text-slate-400 mt-0.5">
                      Deprecated authorization headers (e.g. legacy HMAC signature) processed via fallback compatibility layer with zero transaction drops. Action: developer outreach and deprecation milestones.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'limitations' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 space-y-2 text-rose-200">
                <h4 className="text-sm font-bold text-rose-100 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-400" />
                  Accuracy Guardrails &amp; Financial Safety Rules
                </h4>
                <p>
                  To prevent misleading escalations and protect customer trust, the analyzer adheres to strict truth boundaries:
                </p>
              </div>

              <div className="space-y-2.5">
                <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-200">No Unsubstantiated Financial Claims:</strong>
                    <p className="text-slate-400 mt-0.5">
                      Do not claim that the customer was charged twice, money was lost, or orders were cancelled unless the logs provide verified proof. The analyzer clearly separates verified observations from diagnostic hypotheses.
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-200">No Automated Remediation Execution:</strong>
                    <p className="text-slate-400 mt-0.5">
                      The tool provides recommended containment steps and diagnostic verification queries, but does NOT connect to live production card schemes or execute mutations. Support engineer review is mandatory.
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-200">Simulated Telemetry Focus:</strong>
                    <p className="text-slate-400 mt-0.5">
                      Designed to ingest simulated, test, or sanitized telemetry logs. All sample logs are clearly labeled as simulated test scenarios.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'testing' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Authorization Case Study Test Matrix (P1–P4)
                </h4>
                <p>
                  Validated against four authorization operational presets covering the full priority spectrum:
                </p>
              </div>

              <div className="space-y-2.5">
                <div className="p-3 rounded-lg bg-slate-950/50 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200">1. P1 CRITICAL: Payment Authorization Blackout (Key Expired &amp; 3DS Failure)</span>
                    <span className="font-mono text-[10px] text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/40">PASSED [Critical / P1]</span>
                  </div>
                  <p className="text-slate-400 text-[11px]">
                    Verified detection of RS256 signing key expiry (auth-key-2026-q3), HTTP 401 Unauthorized, CircuitBreaker OPEN on IssuerAuthSwitch, and 100% checkout stoppage. Prioritized containment: emergency KMS hot-swap and canary reset.
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/50 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200">2. P2 HIGH: Merchant OAuth Token Desync &amp; 403 Rejections</span>
                    <span className="font-mono text-[10px] text-orange-400 bg-orange-950/60 px-2 py-0.5 rounded border border-orange-800/40">PASSED [High / P2]</span>
                  </div>
                  <p className="text-slate-400 text-[11px]">
                    Verified detection of Redis auth-cache-02 desynchronization, stale scope metadata (payments:read instead of payments:write), and 34% failure surge. Prioritized steps: drain bad cache node and force token re-issuance.
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/50 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200">3. P3 MEDIUM: Pre-Auth Hold Approved, Capture Unauthorized</span>
                    <span className="font-mono text-[10px] text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/40">PASSED [Medium / P3]</span>
                  </div>
                  <p className="text-slate-400 text-[11px]">
                    Verified detection of pre-auth hold ($115.00, ref=AUTH_OK_9921) with subsequent capture rejection (HTTP 400 AUTHORIZATION_STALE_OR_UNMATCHED). Prioritized steps: block customer card re-authorizations and audit payload fields.
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/50 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200">4. P4 LOW: Deprecated Authorization Header Schema Warning</span>
                    <span className="font-mono text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">PASSED [Low / P4]</span>
                  </div>
                  <p className="text-slate-400 text-[11px]">
                    Verified detection of legacy X-Merchant-Signature-v1 headers processed via fallback layer with zero transaction drops. Prioritized steps: verify fallback health and schedule developer migration notices.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 font-mono">
            AI Incident Analyzer v1.0.0 • Fintech TechOps
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
