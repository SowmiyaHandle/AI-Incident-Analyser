import React from 'react';
import { AnalysisResult } from '../types/incident';
import { SeverityBadge } from './SeverityBadge';
import {
  Sparkles,
  Cpu,
  Clock,
  Layers,
  AlertOctagon,
  AlertTriangle,
  Server,
  FileSpreadsheet,
} from 'lucide-react';

interface IncidentOverviewProps {
  result: AnalysisResult;
}

export const IncidentOverview: React.FC<IncidentOverviewProps> = ({ result }) => {
  const isAI = result.analysisMode === 'gemini-ai';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
      {/* Top Banner: Incident ID, Severity, Analysis Engine Mode */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold border border-slate-700">
              {result.incidentId}
            </span>
            <SeverityBadge severity={result.severity} size="lg" />
            <span
              className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-semibold border ${
                isAI
                  ? 'bg-indigo-950/70 text-indigo-300 border-indigo-700/60'
                  : 'bg-amber-950/60 text-amber-300 border-amber-700/60'
              }`}
            >
              {isAI ? (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Gemini 3.8 Flash AI Analysis</span>
                </>
              ) : (
                <>
                  <Cpu className="w-3.5 h-3.5 text-amber-400" />
                  <span>Rule-Based Deterministic Engine</span>
                </>
              )}
            </span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            {result.incidentTitle}
          </h2>
        </div>

        {/* Timestamp & Duration */}
        <div className="flex flex-col sm:flex-row md:flex-col items-start md:items-end gap-1 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>Triage Time: {new Date(result.generatedAt).toLocaleTimeString()}</span>
          </div>
          <div className="text-[11px] text-slate-500">
            Window: {result.timeWindow.duration || 'N/A'} duration
          </div>
        </div>
      </div>

      {/* Severity Rationale Callout Box */}
      <div
        className={`p-3.5 rounded-lg border text-xs leading-relaxed ${
          result.severity === 'Critical'
            ? 'bg-rose-950/30 border-rose-800/50 text-rose-200'
            : result.severity === 'High'
            ? 'bg-orange-950/30 border-orange-800/50 text-orange-200'
            : result.severity === 'Medium'
            ? 'bg-amber-950/30 border-amber-800/50 text-amber-200'
            : 'bg-emerald-950/30 border-emerald-800/50 text-emerald-200'
        }`}
      >
        <div className="flex items-center gap-1.5 font-bold uppercase tracking-wide mb-1">
          <AlertOctagon className="w-4 h-4 shrink-0" />
          <span>Severity Justification & Operational Impact:</span>
        </div>
        <p className="opacity-95">{result.severityReason}</p>
      </div>

      {/* Executive Summary */}
      <div className="text-xs text-slate-300 leading-relaxed bg-slate-950/50 p-3.5 rounded-lg border border-slate-800/80">
        <span className="font-semibold text-slate-100 block mb-1">Incident Summary:</span>
        {result.summary}
      </div>

      {/* Quick KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-lg p-3">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-1">
            <Server className="w-3.5 h-3.5 text-indigo-400" />
            Impacted Services
          </div>
          <div className="text-lg font-bold text-slate-100">
            {result.affectedServices.length}
          </div>
          <div className="flex flex-wrap gap-1 mt-1.5">
            {result.affectedServices.length > 0 ? (
              result.affectedServices.map((svc) => (
                <span
                  key={svc}
                  className="font-mono text-[10px] bg-slate-800 text-indigo-300 px-1.5 py-0.5 rounded border border-slate-700"
                >
                  {svc}
                </span>
              ))
            ) : (
              <span className="text-[11px] text-slate-500">None detected</span>
            )}
          </div>
        </div>

        <div className="bg-slate-950/70 border border-slate-800/80 rounded-lg p-3">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-1">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            Total Errors
          </div>
          <div className="text-lg font-bold text-rose-400">
            {result.errorCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {result.warningCount} warnings recorded
          </div>
        </div>

        <div className="bg-slate-950/70 border border-slate-800/80 rounded-lg p-3">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-1">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            Repeated Signatures
          </div>
          <div className="text-lg font-bold text-cyan-300">
            {result.repeatedErrors.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Deduplicated clusters
          </div>
        </div>

        <div className="bg-slate-950/70 border border-slate-800/80 rounded-lg p-3">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-1">
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            Parsed Lines
          </div>
          <div className="text-lg font-bold text-slate-100">
            {result.totalLinesParsed}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Stream processed
          </div>
        </div>
      </div>
    </div>
  );
};
