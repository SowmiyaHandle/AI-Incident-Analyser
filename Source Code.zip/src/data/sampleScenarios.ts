import { ScenarioPreset } from '../types/incident';

export const SAMPLE_SCENARIOS: ScenarioPreset[] = [
  {
    id: 'p1-auth-blackout-signing-key-expired',
    name: 'P1 CRITICAL: Payment Authorization Blackout (Key Expired & 3DS Failure)',
    shortDesc: 'Card authorizations failing globally with HTTP 401 / RS256 signature verification failed; 100% checkout stoppage',
    expectedSeverity: 'Critical',
    icon: 'AlertOctagon',
    logs: `11:00:01 INFO Inbound card authorization request | auth_id=AUTH_8801 | card_bin=411111 | amount=$350.00 | merchant_id=MERCH_44
11:00:02 INFO Requesting 3DS2 challenge authorization token from IssuerAuthSwitch
11:00:03 ERROR Authorization token signature validation failed: RS256 signature verification failed (KEY_EXPIRED: auth-key-2026-q3)
11:00:04 ERROR [auth-service] 3DS2 cardholder authentication aborted: HTTP 401 UNAUTHORIZED | token_id=JWT_9901
11:00:05 ERROR [payment-orchestrator] PaymentAuthorizationException: Card issuer authorization refused due to invalid security token signature
11:00:08 ERROR Consecutive authorization failures (42) exceeded threshold (95%); 3DS2 challenge cluster unresponsive
11:00:10 CRITICAL [payment-gw-svc] CircuitBreaker state transitioned to OPEN for target 'IssuerAuthSwitch'
11:00:12 FATAL Global payment authorization blackout: 100% of customer checkout authorizations failing across all merchant channels`,
  },
  {
    id: 'p2-oauth-token-desync',
    name: 'P2 HIGH: Merchant OAuth Token Desync & 403 Rejections',
    shortDesc: 'Intermittent 403 Forbidden errors (34% failure rate) caused by stale scope metadata between Auth cache and processor',
    expectedSeverity: 'High',
    icon: 'AlertTriangle',
    logs: `11:05:01 INFO Payment authorization request received | auth_id=AUTH_8802 | merchant_id=MERCH_89 | amount=$89.99
11:05:02 INFO Verifying merchant OAuth bearer token | token_id=m_tok_77201
11:05:03 ERROR Authorization failed: HTTP 403 FORBIDDEN | error=INSUFFICIENT_SCOPE | required=payments:write granted=payments:read
11:05:04 WARN Distributed token cache desynchronization: Redis auth node auth-cache-02 returning stale scope metadata for merchant MERCH_89
11:05:10 INFO Payment authorization request received | auth_id=AUTH_8803 | merchant_id=MERCH_89 | amount=$120.00
11:05:11 ERROR Authorization failed: HTTP 403 FORBIDDEN | error=TOKEN_EXPIRED (cache ttl mismatch)
11:05:15 WARN Merchant authorization failure rate surged to 34% on cluster us-east-auth`,
  },
  {
    id: 'p3-preauth-hold-capture-unmatched',
    name: 'P3 MEDIUM: Pre-Auth Hold Approved, Capture Unauthorized',
    shortDesc: 'Customer card hold placed with AUTH_APPROVED, but post-auth capture rejected as stale; order held pending reconciliation',
    expectedSeverity: 'Medium',
    icon: 'CreditCard',
    logs: `11:10:00 INFO Card pre-authorization hold initiated | auth_id=AUTH_8804 | order_id=ORD_4401 | amount=$115.00
11:10:01 INFO Issuer response received: AUTH_APPROVED | auth_code=AUTH_OK_9921 | hold_duration=7d
11:10:02 INFO Pre-authorization hold placed on customer credit line for $115.00
11:10:30 INFO Merchant batch settlement dispatch attempting post-auth capture | auth_id=AUTH_8804
11:10:31 ERROR Capture rejected by payment processor: HTTP 400 AUTHORIZATION_STALE_OR_UNMATCHED | ref=AUTH_OK_9921
11:10:35 WARN Order state mismatch: customer credit line has pending authorization hold, but merchant order capture marked UNAUTHORIZED`,
  },
  {
    id: 'p4-deprecated-auth-header-warning',
    name: 'P4 LOW: Deprecated Authorization Header Schema Warning',
    shortDesc: 'Legacy HMAC signature header detected and processed via fallback compatibility layer; zero authorization drops',
    expectedSeverity: 'Low',
    icon: 'AlertCircle',
    logs: `11:15:00 INFO Processing card authorization payload | auth_id=AUTH_8805 | merchant_id=MERCH_12
11:15:01 WARN [auth-gateway] Merchant sending deprecated authorization header 'X-Merchant-Signature-v1'; migrate to 'Authorization: Bearer <v2_jwt>'
11:15:02 INFO Legacy authorization signature verified via compatibility fallback layer; zero authorization drops
11:15:03 INFO Authorization approved | auth_code=AUTH_OK_1204 | status=AUTHORIZED`,
  },
];
