import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '15mb' }));

// Initialize Google GenAI client if key exists
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    geminiConfigured: !!process.env.GEMINI_API_KEY,
    model: 'gemini-3.8-flash',
    timestamp: new Date().toISOString(),
  });
});

// Deterministic rule-based analyzer function
interface AnalysisPayload {
  logs: string;
  forceRuleBased?: boolean;
}

export interface RuleBasedAnalysis {
  analysisMode: 'gemini-ai' | 'rule-based';
  modeLabel: string;
  incidentId: string;
  incidentTitle: string;
  generatedAt: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  severityReason: string;
  summary: string;
  totalLinesParsed: number;
  errorCount: number;
  warningCount: number;
  affectedServices: string[];
  timeWindow: {
    start?: string;
    end?: string;
    duration?: string;
  };
  repeatedErrors: Array<{
    signature: string;
    count: number;
    sampleMessage: string;
    firstSeen: string;
    lastSeen: string;
    affectedServices: string[];
  }>;
  confirmedEvidence: Array<{
    id: string;
    category: string;
    description: string;
    rawExtract: string;
    sourceLine?: number;
    dataPoints: string[];
  }>;
  possibleRootCauses: Array<{
    id: string;
    hypothesis: string;
    likelihood: 'High' | 'Medium' | 'Low';
    rationale: string;
    validationSteps: string[];
  }>;
  troubleshootingSteps: Array<{
    stepNumber: number;
    priority: 'P1' | 'P2' | 'P3' | 'P4';
    title: string;
    action: string;
    expectedOutcome: string;
  }>;
  escalation: {
    shouldEscalate: boolean;
    targetTier: 'L1' | 'L2' | 'L3' | 'None';
    triggerCondition: string;
    onCallTeam: string;
    slaResponseTime: string;
    escalationChecklist: string[];
  };
}

function runRuleBasedAnalysis(logs: string): RuleBasedAnalysis {
  const lines = logs.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const totalLines = lines.length;

  let errorCount = 0;
  let warningCount = 0;
  const servicesSet = new Set<string>();
  const timestamps: string[] = [];

  const errorMap = new Map<
    string,
    { count: number; sample: string; first: string; last: string; services: Set<string> }
  >();
  const evidenceList: RuleBasedAnalysis['confirmedEvidence'] = [];

  const warningRegex = /\b(WARN|WARNING)\b/i;
  const errorRegex = /\b(ERROR|FATAL|CRITICAL|SEVERE|Exception|Err|FAILED)\b/i;

  // Case Study Detection Patterns: Payment Successful, but Merchant Confirmation Missing
  const hasGatewaySuccess = /status=SUCCESS|Gateway response received.*SUCCESS/i.test(logs);
  const hasMerchantCallbackFailed = /Merchant callback failed|error=TIMEOUT|callback.*timeout/i.test(logs);
  const hasMerchantPending = /Merchant payment status remains PENDING|status=PENDING/i.test(logs);
  const isPaymentSuccessMissingConfirmationCase = hasGatewaySuccess && (hasMerchantCallbackFailed || hasMerchantPending);

  // Extract transaction IDs and Gateway references
  const txnMatches = Array.from(new Set(Array.from(logs.matchAll(/txn_id=([a-zA-Z0-9_-]+)/g)).map((m) => m[1])));
  const refMatches = Array.from(new Set(Array.from(logs.matchAll(/ref=([a-zA-Z0-9_-]+)/g)).map((m) => m[1])));
  const primaryTxnId = txnMatches[0] || 'TXN1001';
  const primaryRefId = refMatches[0] || 'GW5001';

  // Specific regexes
  const paymentTimeoutRegex = /(timeout|timed out|504|Gateway Timeout|ETIMEDOUT|ConnectTimeout)/i;
  const dbFailureRegex = /(database|postgres|connection refused|HikariPool|pool exhausted|too many connections|deadlock|SQLSTATE|53300)/i;

  let hasCircuitBreaker = false;
  let maxLatencyFound = 0;

  lines.forEach((line, index) => {
    // Extract timestamp (support HH:MM:SS as well as ISO8601)
    const tsMatch =
      line.match(/\b\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?\b/) ||
      line.match(/\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b/);
    if (tsMatch) {
      timestamps.push(tsMatch[0]);
    }

    // Extract service
    const svcMatch =
      line.match(/\[([a-zA-Z0-9_-]+(?:svc|service|api|worker|db|engine|feed|processor))\]/i) ||
      line.match(/service=([a-zA-Z0-9_-]+)/i) ||
      line.match(/\b([a-zA-Z0-9_-]+(?:-svc|-service|-api|-worker|-processor))\b/i);
    
    let serviceName = svcMatch ? svcMatch[1] : '';
    if (!serviceName) {
      if (/Merchant callback|Merchant payment/i.test(line)) serviceName = 'merchant-webhook-service';
      else if (/Gateway response|Gateway reference/i.test(line)) serviceName = 'payment-gateway-adapter';
      else if (/Payment request/i.test(line)) serviceName = 'payment-orchestrator';
    }

    if (serviceName) {
      servicesSet.add(serviceName);
    }

    // Latency extraction
    const latencyMatch = line.match(/(\d+(?:\.\d+)?)\s*(?:ms|milliseconds)/i);
    if (latencyMatch) {
      const lat = parseFloat(latencyMatch[1]);
      if (lat > maxLatencyFound) maxLatencyFound = lat;
    }

    const isWarn = warningRegex.test(line) && !errorRegex.test(line);
    const isErr = errorRegex.test(line);

    if (isWarn) warningCount++;
    if (isErr) errorCount++;

    if (/circuit\s*breaker/i.test(line) || /state:\s*OPEN/i.test(line)) {
      hasCircuitBreaker = true;
    }

    // Normalize error/warn signature
    if (isErr || isWarn) {
      const normalizedSig = line
        .replace(/\b(?:\d{4}-\d{2}-\d{2}[T ])?\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?\b/g, '')
        .replace(/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/g, '<UUID>')
        .replace(/\b(txn_id=)[a-zA-Z0-9_-]+/gi, '$1<TXN>')
        .replace(/\b(ref=)[a-zA-Z0-9_-]+/gi, '$1<REF>')
        .replace(/0x[0-9a-fA-F]+/g, '<ADDR>')
        .replace(/\b\d{5,}\b/g, '<NUM>')
        .substring(0, 110)
        .trim();

      const existing = errorMap.get(normalizedSig) || {
        count: 0,
        sample: line,
        first: tsMatch ? tsMatch[0] : `Line ${index + 1}`,
        last: tsMatch ? tsMatch[0] : `Line ${index + 1}`,
        services: new Set<string>(),
      };
      existing.count++;
      if (tsMatch) existing.last = tsMatch[0];
      if (serviceName) existing.services.add(serviceName);
      errorMap.set(normalizedSig, existing);
    }
  });

  const repeatedErrors = Array.from(errorMap.entries())
    .map(([sig, val]) => ({
      signature: sig,
      count: val.count,
      sampleMessage: val.sample,
      firstSeen: val.first,
      lastSeen: val.last,
      affectedServices: Array.from(val.services),
    }))
    .sort((a, b) => b.count - a.count);

  // Time window calculation
  let timeStart = timestamps[0];
  let timeEnd = timestamps[timestamps.length - 1];
  let duration = 'N/A';
  if (timeStart && timeEnd && timeStart !== timeEnd) {
    if (timeStart.includes('T') && timeEnd.includes('T')) {
      try {
        const ms = Math.abs(new Date(timeEnd).getTime() - new Date(timeStart).getTime());
        const mins = Math.floor(ms / 60000);
        const secs = Math.floor((ms % 60000) / 1000);
        duration = mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
      } catch {
        duration = 'Indeterminate';
      }
    } else {
      duration = `${timeStart} to ${timeEnd}`;
    }
  }

  let severity: RuleBasedAnalysis['severity'] = 'Medium';
  let severityReason = '';
  let incidentTitle = 'Payment Authorization State Triage';
  let incidentSummary = '';
  const possibleRootCauses: RuleBasedAnalysis['possibleRootCauses'] = [];
  const troubleshootingSteps: RuleBasedAnalysis['troubleshootingSteps'] = [];

  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const incidentId = `INC-${dateStr}-${randomSuffix}`;

  // Authorization Case Study Detection
  const isP1AuthBlackout = /KEY_EXPIRED|RS256 signature verification failed|CircuitBreaker.*IssuerAuthSwitch|Global payment authorization blackout/i.test(logs);
  const isP2OAuthTokenDesync = /INSUFFICIENT_SCOPE|Distributed token cache desynchronization|cache ttl mismatch|surged to 34%/i.test(logs);
  const isP3PreAuthHold = /pre-authorization hold|AUTH_APPROVED|AUTHORIZATION_STALE_OR_UNMATCHED|Order state mismatch/i.test(logs);
  const isP4DeprecatedHeader = /deprecated authorization header|X-Merchant-Signature-v1|compatibility fallback layer|legacy authorization signature/i.test(logs);

  if (isP1AuthBlackout) {
    severity = 'Critical';
    incidentTitle = 'P1 CRITICAL: Payment Authorization Blackout (Key Expired & 3DS Failure)';
    severityReason = 'P1 CRITICAL SEVERITY: Card issuer authorization token signing key (auth-key-2026-q3) has expired, failing RS256 signature verification across all incoming 3DS2 challenges. Consecutive authorization failures (42) tripped the CircuitBreaker to OPEN on IssuerAuthSwitch, halting 100% of customer card checkout authorizations across all channels.';
    incidentSummary = `P1 CRITICAL Outage: Global payment authorization blackout affecting 100% of customer checkouts. RS256 signing key expired on IssuerAuthSwitch, tripping circuit breaker to OPEN. Emergency key hot-swap and canary reset required immediately.`;

    evidenceList.push(
      {
        id: 'EV-01',
        category: 'Cryptographic Signature Verification Failure',
        description: 'Issuer token signing key failed RS256 signature verification with error KEY_EXPIRED: auth-key-2026-q3.',
        rawExtract: lines.find((l) => /KEY_EXPIRED|RS256 signature verification failed/i.test(l)) || 'ERROR Authorization token signature validation failed: RS256 signature verification failed (KEY_EXPIRED: auth-key-2026-q3)',
        dataPoints: [
          'Cryptographic RS256 signature validation rejected by auth switch',
          'Key ID auth-key-2026-q3 expired in local JWKS keystore',
          'HTTP 401 UNAUTHORIZED generated for cardholder 3DS2 token JWT_9901',
        ],
      },
      {
        id: 'EV-02',
        category: 'Perimeter Circuit Breaker State Transition',
        description: 'Payment gateway circuit breaker transitioned from CLOSED to OPEN for target IssuerAuthSwitch.',
        rawExtract: lines.find((l) => /CircuitBreaker.*IssuerAuthSwitch/i.test(l)) || 'CRITICAL [payment-gw-svc] CircuitBreaker state transitioned to OPEN for target \'IssuerAuthSwitch\'',
        dataPoints: [
          'Circuit breaker tripped to OPEN following 42 consecutive failures',
          'Failure rate threshold (95%) breached',
          'Inbound authorization requests rejected at gateway perimeter to protect upstream',
        ],
      },
      {
        id: 'EV-03',
        category: 'Global Checkout Impact Boundary',
        description: '100% of customer card checkout authorizations failing globally across all merchant channels.',
        rawExtract: lines.find((l) => /Global payment authorization blackout/i.test(l)) || 'FATAL Global payment authorization blackout: 100% of customer checkout authorizations failing across all merchant channels',
        dataPoints: [
          '100% authorization drop rate across all merchant channels',
          'Zero card payments completing successfully',
          'Confirmed Evidence Boundary: Cryptographic key expiry and circuit breaker trip verified; no customer accounts debited for failed authorizations',
        ],
      }
    );

    possibleRootCauses.push(
      {
        id: 'HYP-01',
        hypothesis: 'Public Key Infrastructure (PKI) rotation desynchronization between IssuerAuthSwitch and gateway auth service.',
        likelihood: 'High',
        rationale: 'Active signing key auth-key-2026-q3 surpassed its cryptographic validity window without an automated rollover to the Q4 key pair.',
        validationSteps: [
          'Fetch active JWKS endpoint from issuer auth cluster and inspect key expiration headers',
          'Verify whether public key certificate was updated in gateway truststore',
          'Check AWS KMS / HSM vault key rotation audit logs for key auth-key-2026-q4',
        ],
      },
      {
        id: 'HYP-02',
        hypothesis: 'JWKS caching layer TTL misconfiguration preventing fresh public key set ingestion.',
        likelihood: 'Medium',
        rationale: 'If auth-service cached the previous JWKS indefinitely without honoring cache-control headers, newly rotated issuer keys would be rejected.',
        validationSteps: [
          'Inspect Redis/in-memory JWKS cache TTL on auth-service pods',
          'Execute manual curl probe against issuer .well-known/jwks.json',
        ],
      }
    );

    troubleshootingSteps.push(
      {
        stepNumber: 1,
        priority: 'P1',
        title: 'P1 Containment: Emergency Hot-Swap to Active Signing Key Pair',
        action: 'Trigger emergency KMS/HSM key alias update to point auth-key-current to validated standby key pair auth-key-2026-q4 in the key vault, and purge stale JWKS cache.',
        expectedOutcome: 'Valid signature generation restored immediately; halts 401 UNAUTHORIZED rejection cascade.',
      },
      {
        stepNumber: 2,
        priority: 'P2',
        title: 'P2 Diagnostic: Verify Issuer JWKS Propagation & 3DS2 Challenge Handshake',
        action: 'Execute synthetic end-to-end 3DS2 test authorization via internal canary card BIN 411111 and verify HTTP 200 response with valid signature verification.',
        expectedOutcome: 'Confirms issuer auth switch and 3DS challenge cluster accept newly propagated cryptographic signatures.',
      },
      {
        stepNumber: 3,
        priority: 'P3',
        title: 'P3 Remediation: Reset CircuitBreaker to HALF-OPEN & Drain Queued Authorizations',
        action: 'Transition IssuerAuthSwitch circuit breaker from OPEN to HALF-OPEN with a 10% canary traffic allocation before restoring full production load.',
        expectedOutcome: 'Safely re-introduces merchant checkout traffic without overwhelming auth services.',
      },
      {
        stepNumber: 4,
        priority: 'P4',
        title: 'P4 Prevention: Deploy Automated 30-Day PKI Pre-Expiry Monitor & Key Rotation Pipeline',
        action: 'Implement automated certificate expiration alerts (30d/14d/7d) in Prometheus/Datadog and mandate zero-downtime dual-key rollover in CI/CD.',
        expectedOutcome: 'Prevents recurrence of catastrophic signing key expirations.',
      }
    );
  } else if (isP2OAuthTokenDesync) {
    severity = 'High';
    incidentTitle = 'P2 HIGH: Merchant OAuth Token Desync & 403 Rejections';
    severityReason = 'P2 HIGH SEVERITY: Distributed token cache node (auth-cache-02) is serving stale scope metadata (payments:read instead of required payments:write), causing a 34% surge in HTTP 403 Forbidden authorization rejections for active merchants. Core payment processing remains functional on healthy cache nodes.';
    incidentSummary = `P2 HIGH Degradation: Merchant OAuth token scope desynchronization on auth cache node auth-cache-02 causing 34% authorization rejections (HTTP 403 INSUFFICIENT_SCOPE). Drain desynced node and re-issue merchant tokens.`;

    evidenceList.push(
      {
        id: 'EV-01',
        category: 'HTTP 403 Forbidden with Scope Mismatch',
        description: 'Authorization failed with HTTP 403 FORBIDDEN due to INSUFFICIENT_SCOPE (required=payments:write, granted=payments:read).',
        rawExtract: lines.find((l) => /INSUFFICIENT_SCOPE/i.test(l)) || 'ERROR Authorization failed: HTTP 403 FORBIDDEN | error=INSUFFICIENT_SCOPE | required=payments:write granted=payments:read',
        dataPoints: [
          'Token m_tok_77201 rejected due to missing payments:write scope',
          'Token validation failed at auth perimeter',
          'Merchant unable to authorize transactions for order checkouts',
        ],
      },
      {
        id: 'EV-02',
        category: 'Distributed Token Cache Inconsistency',
        description: 'Distributed token cache node auth-cache-02 returning stale scope metadata for merchant MERCH_89.',
        rawExtract: lines.find((l) => /Distributed token cache desynchronization/i.test(l)) || 'WARN Distributed token cache desynchronization: Redis auth node auth-cache-02 returning stale scope metadata for merchant MERCH_89',
        dataPoints: [
          'Redis node auth-cache-02 out of sync with primary auth cluster',
          'Cache TTL mismatch causing premature expiration and stale permission masks',
          'Cluster error rate surged to 34% on us-east-auth',
        ],
      }
    );

    possibleRootCauses.push(
      {
        id: 'HYP-01',
        hypothesis: 'Redis replica replication lag or stale key eviction failure on node auth-cache-02.',
        likelihood: 'High',
        rationale: 'Merchant permissions were upgraded in database but replication stream to auth-cache-02 stalled or missed the invalidation event.',
        validationSteps: [
          'Run Redis INFO REPLICATION on auth-cache-02 and check master_link_down_since_seconds',
          'Compare token scope hash between master and replica node for MERCH_89',
        ],
      },
      {
        id: 'HYP-02',
        hypothesis: 'Race condition during asynchronous OAuth scope update webhook dispatch.',
        likelihood: 'Medium',
        rationale: 'Cache invalidation event was lost or delivered out of sequence during merchant role adjustment.',
        validationSteps: [
          'Inspect Kafka/RabbitMQ consumer lag on auth-invalidation-topic',
          'Review merchant audit trail for MERCH_89 in merchant portal',
        ],
      }
    );

    troubleshootingSteps.push(
      {
        stepNumber: 1,
        priority: 'P1',
        title: 'P1 Containment: Drain Traffic from Desynced Auth Cache Node',
        action: 'Remove auth-cache-02 from Envoy/HAProxy load balancer rotation and route all token verification traffic to synced healthy nodes (auth-cache-01, auth-cache-03).',
        expectedOutcome: 'Immediately halts 403 Forbidden rejections for merchants; restores 100% valid token acceptance.',
      },
      {
        stepNumber: 2,
        priority: 'P2',
        title: 'P2 Diagnostic: Inspect Redis Replication Offset & Token Scope Keys',
        action: 'Execute REDIS-CLI -h auth-cache-02 INFO replication and inspect key token:scope:MERCH_89 against the primary auth datastore.',
        expectedOutcome: 'Pinpoints exact replication lag delta or corrupted key state.',
      },
      {
        stepNumber: 3,
        priority: 'P3',
        title: 'P3 Remediation: Invalidate Stale Cache Keys & Re-issue Merchant Token',
        action: 'Flush stale cache keys for affected merchants on replica cluster and invoke OAuth token refresh endpoint for MERCH_89.',
        expectedOutcome: 'Forces clean scope synchronization with payments:write permissions.',
      },
      {
        stepNumber: 4,
        priority: 'P4',
        title: 'P4 Prevention: Deploy Read-After-Write Cache Consistency Check & Drift Alarms',
        action: 'Configure automated synthetic cache consistency probes comparing master vs replica scope keys every 60 seconds with PagerDuty alerts on drift > 2 seconds.',
        expectedOutcome: 'Prevents silent cache divergence from impacting payment operations.',
      }
    );
  } else if (isP3PreAuthHold) {
    severity = 'Medium';
    incidentTitle = 'P3 MEDIUM: Pre-Auth Hold Approved, Capture Unauthorized';
    severityReason = 'P3 MEDIUM SEVERITY: Customer card pre-authorization hold ($115.00, ref=AUTH_OK_9921) was approved by issuer, but subsequent merchant batch settlement capture was rejected with HTTP 400 AUTHORIZATION_STALE_OR_UNMATCHED. An isolated order state divergence exists; customer funds are held on credit line but order fulfillment is pending.';
    incidentSummary = `P3 MEDIUM Asynchrony: Pre-authorization hold ($115.00, ref=AUTH_OK_9921) approved on customer card, but batch settlement capture was rejected as stale/unmatched. Order held pending reference audit to prevent duplicate holds.`;

    evidenceList.push(
      {
        id: 'EV-01',
        category: 'Pre-Authorization Hold Approved by Card Issuer',
        description: 'Issuer response received AUTH_APPROVED with auth_code=AUTH_OK_9921 and hold_duration=7d.',
        rawExtract: lines.find((l) => /AUTH_APPROVED/i.test(l)) || 'INFO Issuer response received: AUTH_APPROVED | auth_code=AUTH_OK_9921 | hold_duration=7d',
        dataPoints: [
          'Pre-auth hold approved for $115.00 on customer card credit line',
          'Auth reference code AUTH_OK_9921 generated by card issuer',
          'Hold window active for 7 days',
        ],
      },
      {
        id: 'EV-02',
        category: 'Capture Rejected by Processor',
        description: 'Post-auth capture attempt rejected by payment processor with HTTP 400 AUTHORIZATION_STALE_OR_UNMATCHED.',
        rawExtract: lines.find((l) => /AUTHORIZATION_STALE_OR_UNMATCHED/i.test(l)) || 'ERROR Capture rejected by payment processor: HTTP 400 AUTHORIZATION_STALE_OR_UNMATCHED | ref=AUTH_OK_9921',
        dataPoints: [
          'Merchant capture attempt failed with HTTP 400',
          'Processor rejected capture payload for auth_id=AUTH_8804',
          'Order ORD_4401 fulfillment blocked',
        ],
      },
      {
        id: 'EV-03',
        category: 'State Mismatch Boundary',
        description: 'Customer credit line has pending authorization hold, but merchant order capture marked UNAUTHORIZED.',
        rawExtract: lines.find((l) => /Order state mismatch/i.test(l)) || 'WARN Order state mismatch: customer credit line has pending authorization hold, but merchant order capture marked UNAUTHORIZED',
        dataPoints: [
          'Confirmed divergence: Hold active upstream, capture failed downstream',
          'Confirmed Evidence Boundary: Logs prove state mismatch; logs do NOT prove customer was debited twice or money lost',
        ],
      }
    );

    possibleRootCauses.push(
      {
        id: 'HYP-01',
        hypothesis: 'Settlement dispatch worker passed mismatched authorization reference or corrupted auth_code in capture payload.',
        likelihood: 'High',
        rationale: 'Logs report AUTHORIZATION_STALE_OR_UNMATCHED; subtle formatting discrepancy or order ID collision between pre-auth and capture.',
        validationSteps: [
          'Inspect outbound JSON payload sent by batch settlement dispatcher to processor API',
          'Verify whether auth_code AUTH_OK_9921 was truncated or mapped to wrong order',
        ],
      },
      {
        id: 'HYP-02',
        hypothesis: 'Processor pre-auth hold window expired prematurely due to timezone/epoch clock skew.',
        likelihood: 'Medium',
        rationale: 'If processor enforces strict 7-day or short intraday auth windows with clock skew, valid holds can be marked stale.',
        validationSteps: [
          'Check NTP synchronization status on payment processor gateway adapter',
          'Query processor transaction ledger via Virtual Terminal',
        ],
      }
    );

    troubleshootingSteps.push(
      {
        stepNumber: 1,
        priority: 'P1',
        title: 'P1 Containment: Block Blind Re-Authorizations & Protect Cardholder Credit Line',
        action: 'Prevent customer support or automated checkout retry from initiating a second pre-auth hold on customer credit line for order ORD_4401.',
        expectedOutcome: 'Prevents customer credit line from being blocked with duplicate pre-auth holds.',
      },
      {
        stepNumber: 2,
        priority: 'P2',
        title: 'P2 Diagnostic: Audit Capture Payload Fields Against Issuer Auth Code',
        action: 'Inspect settlement worker payload for auth_id=AUTH_8804 and compare auth_code directly against issuer response record AUTH_OK_9921.',
        expectedOutcome: 'Identifies any payload field mismatch or formatting truncation.',
      },
      {
        stepNumber: 3,
        priority: 'P3',
        title: 'P3 Remediation: Re-Submit Corrected Capture Payload or Issue Order Void',
        action: 'If reference is verified, re-dispatch capture request via processor settlement API; if order canceled, dispatch explicit pre-auth VOID/RELEASE to release hold.',
        expectedOutcome: 'Reconciles transaction state and releases hold or captures funds cleanly.',
      },
      {
        stepNumber: 4,
        priority: 'P4',
        title: 'P4 Prevention: Implement Pre-Capture Reference Validation & Hold Expiry Telemetry',
        action: 'Add schema validation guardrail ensuring auth_code exists and matches issuer authorization table prior to queuing capture jobs.',
        expectedOutcome: 'Eliminates malformed capture attempts at the application layer.',
      }
    );
  } else if (isP4DeprecatedHeader) {
    severity = 'Low';
    incidentTitle = 'P4 LOW: Deprecated Authorization Header Schema Warning';
    severityReason = 'P4 LOW SEVERITY: Merchant MERCH_12 is sending legacy HMAC signature headers (X-Merchant-Signature-v1) which are successfully processed via the backward-compatibility layer. All transactions are authorized (status=AUTHORIZED) with zero transaction drops or customer impact.';
    incidentSummary = `P4 LOW Telemetry Warning: Deprecated HMAC signature header (X-Merchant-Signature-v1) detected for merchant MERCH_12. Processed safely via fallback compatibility layer with zero transaction drops. Schedule developer migration to v2 Bearer tokens.`;

    evidenceList.push(
      {
        id: 'EV-01',
        category: 'Deprecated Header Telemetry Flagged',
        description: 'Merchant sending deprecated authorization header X-Merchant-Signature-v1; migrate to Authorization: Bearer <v2_jwt>.',
        rawExtract: lines.find((l) => /X-Merchant-Signature-v1/i.test(l)) || 'WARN [auth-gateway] Merchant sending deprecated authorization header \'X-Merchant-Signature-v1\'; migrate to \'Authorization: Bearer <v2_jwt>\'',
        dataPoints: [
          'Header X-Merchant-Signature-v1 flagged for migration',
          'Merchant ID MERCH_12 identified',
          'Recommendation: migrate to Authorization: Bearer <v2_jwt>',
        ],
      },
      {
        id: 'EV-02',
        category: 'Zero Transaction Drops via Fallback',
        description: 'Legacy authorization signature verified via compatibility fallback layer; zero authorization drops.',
        rawExtract: lines.find((l) => /compatibility fallback layer/i.test(l)) || 'INFO Legacy authorization signature verified via compatibility fallback layer; zero authorization drops',
        dataPoints: [
          'Fallback layer successfully validated signature',
          'Transaction approved: auth_code=AUTH_OK_1204, status=AUTHORIZED',
          'Zero customer payment impact',
        ],
      }
    );

    possibleRootCauses.push(
      {
        id: 'HYP-01',
        hypothesis: 'Merchant technical team has not yet completed migration to API v2 specification before the announced deprecation date.',
        likelihood: 'High',
        rationale: 'Legacy header format continues to be dispatched by merchant checkout webhook integration.',
        validationSteps: [
          'Check merchant account communication history in Merchant CRM for deprecation notices',
          'Query gateway access logs for other merchants still utilizing v1 headers',
        ],
      }
    );

    troubleshootingSteps.push(
      {
        stepNumber: 1,
        priority: 'P1',
        title: 'P1 Containment: Confirm Fallback Verification Layer Remains Active',
        action: 'Verify that the HMAC compatibility validator service is healthy with low CPU/memory utilization and zero dropped authorizations.',
        expectedOutcome: 'Guarantees uninterrupted processing for merchant transactions.',
      },
      {
        stepNumber: 2,
        priority: 'P2',
        title: 'P2 Diagnostic: Quantify Daily v1 Header Call Volume for Merchant',
        action: 'Run telemetry query in Grafana: sum(rate(http_requests_total{header="X-Merchant-Signature-v1"}[24h])).',
        expectedOutcome: 'Establishes precise transaction volume requiring migration.',
      },
      {
        stepNumber: 3,
        priority: 'P3',
        title: 'P3 Remediation: Issue Automated Developer Portal Migration Notice',
        action: 'Send developer outreach ticket and migration guide to MERCH_12 technical contact with code samples for v2 JWT Bearer authentication.',
        expectedOutcome: 'Merchant initiates SDK update to standard OAuth Bearer tokens.',
      },
      {
        stepNumber: 4,
        priority: 'P4',
        title: 'P4 Prevention: Track Deprecation Sunset Milestones & Staged Enforcement',
        action: 'Configure automated 60/30/14-day reminder notifications leading up to final v1 header sunset cut-off.',
        expectedOutcome: 'Orderly API version lifecycle management without emergency merchant outages.',
      }
    );
  } else if (isPaymentSuccessMissingConfirmationCase) {
    const hasDuplicateCharge = /duplicate charge|double debit|multiple captured transactions/i.test(logs);
    const hasCircuitBreakerTripped = /CircuitBreaker.*OPEN/i.test(logs);
    const hasLedgerDiscrepancy = /ledger discrepancy|financial blast radius/i.test(logs);
    const isCritical = hasDuplicateCharge || hasCircuitBreakerTripped || hasLedgerDiscrepancy;

    if (isCritical) {
      severity = 'Critical';
      incidentTitle = 'CRITICAL: Callback Blackout & Customer Double-Debit Spike';
      severityReason = 'CRITICAL SEVERITY: Systemic merchant callback failure left orders in PENDING status, triggering automated client retry prompts that resulted in confirmed duplicate charges on customer cards. The callback dispatcher circuit breaker is OPEN, and financial ledger discrepancies are actively accumulating.';
      incidentSummary = 'CRITICAL SEVERITY: Merchant callback blackout caused orders to remain PENDING while payment was captured. Immediate gateway void/refund batch and client retry lock required.';

      evidenceList.push(
        {
          id: 'EV-01',
          category: 'Authoritative Gateway Multi-Capture',
          description: 'Payment gateway captured multiple successful authorizations for the same order reference (e.g. GW9001 and GW9002).',
          rawExtract: lines.find((l) => /Duplicate charge confirmed|multiple captured transactions/i.test(l)) || 'CRITICAL Duplicate charge confirmed: multiple captured transactions',
          dataPoints: [
            'Multiple captured transactions registered for single order ID',
            'Cardholder accounts debited multiple times due to uncoordinated retries',
            'Authoritative gateway settlement records show concurrent SUCCESS events',
          ],
        },
        {
          id: 'EV-02',
          category: 'Merchant Webhook Blackout',
          description: 'Merchant callback dispatcher completely failed to deliver confirmations (CONNECTION_REFUSED / 100% failure rate).',
          rawExtract: lines.find((l) => /CONNECTION_REFUSED|error=TIMEOUT/i.test(l)) || 'ERROR Merchant callback failed | error=CONNECTION_REFUSED',
          dataPoints: [
            'Merchant callback endpoint completely unresponsive or rejecting connections',
            'Orders stranded in PENDING state at merchant layer',
            'Failure rate reached 100%, causing cascading retries',
          ],
        }
      );

      possibleRootCauses.push(
        {
          id: 'HYP-01',
          hypothesis: 'Merchant webhook ingress proxy or application cluster crashed.',
          likelihood: 'High',
          rationale: 'Logs report immediate CONNECTION_REFUSED across successive requests, pointing to downed ingress pods.',
          validationSteps: [
            'Inspect merchant webhook ingress pod health and Kubernetes deployment events',
            'Check public DNS and TLS certificate status on merchant webhook domain',
          ],
        }
      );

      troubleshootingSteps.push(
        {
          stepNumber: 1,
          priority: 'P1',
          title: 'P1 Containment: Disable Client Auto-Retry Prompts',
          action: 'Engage emergency feature flag DISABLE_CLIENT_AUTO_RETRY=true on checkout frontend to halt duplicate submissions.',
          expectedOutcome: 'Instantly caps double-debit blast radius and prevents further cardholder double charges.',
        },
        {
          stepNumber: 2,
          priority: 'P2',
          title: 'P2 Diagnostic: Automated Gateway Void / Refund for Duplicate References',
          action: 'Identify all duplicate gateway references and issue automated VOID/REFUND via gateway API.',
          expectedOutcome: 'Reverses unauthorized second debits before funds leave customer accounts.',
        },
        {
          stepNumber: 3,
          priority: 'P3',
          title: 'P3 Remediation: Restore Merchant Callback Ingress & Reset Circuit Breaker',
          action: 'Restart crashed webhook listener pods and verify health check before resetting circuit breaker to HALF-OPEN.',
          expectedOutcome: 'Restores asynchronous transaction delivery stream without packet loss.',
        },
        {
          stepNumber: 4,
          priority: 'P4',
          title: 'P4 Prevention: Deploy Webhook Idempotency Lock & Reconciliation Poller',
          action: 'Enforce gateway reference unique constraints in merchant order database and deploy automated polling fallback.',
          expectedOutcome: 'Prevents future order status discrepancies.',
        }
      );
    } else {
      const affectedTxnCount = txnMatches.length || 1;
      severity = affectedTxnCount > 2 ? 'High' : 'Medium';
      incidentTitle = 'Payment Successful, but Merchant Confirmation Missing';
      severityReason = `The payment gateway authorized the transaction successfully (status=SUCCESS, ref=${primaryRefId}), but the merchant application did not receive payment confirmation due to a callback timeout. Transaction status remains PENDING in the merchant system. Classified as ${severity}.`;
      incidentSummary = `${incidentTitle}. Analyzed ${totalLines} log lines. Gateway confirmed transaction SUCCESS (ref=${primaryRefId}), but merchant callback timed out; order status remains PENDING in merchant system. Reconcile with gateway before retrying to prevent duplicate processing.`;

      evidenceList.push(
        {
          id: 'EV-01',
          category: 'Authoritative Gateway Execution',
          description: `Payment gateway confirmed transaction execution with status=SUCCESS and generated gateway reference ref=${primaryRefId}.`,
          rawExtract: lines.find((l) => /status=SUCCESS/i.test(l)) || `status=SUCCESS | ref=${primaryRefId}`,
          dataPoints: [
            `Gateway status: SUCCESS for txn_id=${primaryTxnId}`,
            `Authoritative reference created: ref=${primaryRefId}`,
            'Gateway confirmed capture of payment authorization',
          ],
        },
        {
          id: 'EV-02',
          category: 'Merchant Webhook / Callback Failure',
          description: `Outbound merchant callback notification failed with error=TIMEOUT.`,
          rawExtract: lines.find((l) => /callback failed/i.test(l)) || 'ERROR Merchant callback failed | error=TIMEOUT',
          dataPoints: [
            'Callback dispatch failed with TIMEOUT error',
            'Merchant application did not acknowledge receipt of confirmation payload',
            'Asynchronous notification pipeline broken for this transaction event',
          ],
        }
      );

      possibleRootCauses.push(
        {
          id: 'HYP-01',
          hypothesis: 'Communication timeout or network latency between payment gateway notification dispatcher and merchant webhook endpoint.',
          likelihood: 'High',
          rationale: 'Gateway recorded SUCCESS and issued ref=' + primaryRefId + ', but the subsequent HTTP POST to merchant timed out.',
          validationSteps: [
            'Verify merchant callback endpoint URL accessibility and response latency using synthetic cURL probe',
            'Inspect gateway outbound egress proxy and firewall logs for dropped TCP packets',
          ],
        }
      );

      troubleshootingSteps.push(
        {
          stepNumber: 1,
          priority: 'P1',
          title: 'P1 Containment: Verify Gateway Status & Prevent Re-attempts',
          action: `Query gateway management API using ref '${primaryRefId}' and confirm SETTLED status. Hold order; do not prompt user to re-pay.`,
          expectedOutcome: 'Confirmed payment proof at financial acquirer before any merchant-side modification.',
        },
        {
          stepNumber: 2,
          priority: 'P2',
          title: 'P2 Diagnostic: Reconcile Merchant Records Without Retrying',
          action: `Update merchant internal order status from PENDING to CONFIRMED based on ref '${primaryRefId}'.`,
          expectedOutcome: 'Customer order unblocked for fulfillment with zero duplicate billing risk.',
        },
        {
          stepNumber: 3,
          priority: 'P3',
          title: 'P3 Remediation: Investigate Endpoint & Trigger Webhook Replay',
          action: 'Inspect merchant webhook receiver health and trigger idempotent webhook replay from gateway dashboard.',
          expectedOutcome: 'Automated webhook delivery pipeline is restored and verified.',
        },
        {
          stepNumber: 4,
          priority: 'P4',
          title: 'P4 Prevention: Configure Status Polling Reconciliation Fallback',
          action: 'Configure automated status polling reconciliation worker to query the gateway for any transaction lingering in PENDING status for > 2 minutes.',
          expectedOutcome: 'Eliminates reliance on single webhook delivery for order fulfillment.',
        }
      );
    }
  } else if (paymentTimeoutRegex.test(logs) && (errorCount > 3 || hasCircuitBreaker)) {
    severity = 'High';
    incidentTitle = 'Payment Gateway Upstream Timeout & Degradation';
    severityReason = 'Outbound payment requests are encountering gateway timeouts; transaction clearing is degraded.';
    incidentSummary = 'Payment gateway upstream timeout and degradation detected. Hold in-flight transactions and inspect partner banking endpoints.';

    possibleRootCauses.push({
      id: 'HYP-01',
      hypothesis: 'Upstream banking partner or payment processing switch is experiencing service degradation.',
      likelihood: 'High',
      rationale: 'Logs show timeouts (>10,000ms) against the partner banking endpoint while internal microservices remain responsive.',
      validationSteps: [
        'Check partner bank public status page and real-time API health dashboard',
        'Execute synthetic probe curl to partner test sandbox endpoint',
      ],
    });

    troubleshootingSteps.push(
      {
        stepNumber: 1,
        priority: 'P1',
        title: 'P1 Containment: Hold In-Flight Transactions & Prevent Duplicate Charges',
        action: 'Hold transactions in PENDING status. Do not issue blind retries to prevent duplicate customer charges.',
        expectedOutcome: 'Zero financial double-charge risk for cardholders.',
      },
      {
        stepNumber: 2,
        priority: 'P2',
        title: 'P2 Diagnostic: Run Synthetic Health Probes Against Partner Bank API',
        action: 'Execute synthetic probes to isolate whether network latency is internal or upstream.',
        expectedOutcome: 'Isolates source of degradation.',
      },
      {
        stepNumber: 3,
        priority: 'P3',
        title: 'P3 Remediation: Failover to Secondary Acquirer Gateway',
        action: 'Reroute incoming payment authorizations to standby acquiring bank route.',
        expectedOutcome: 'Restores payment authorization success rate.',
      },
      {
        stepNumber: 4,
        priority: 'P4',
        title: 'P4 Prevention: Configure Dynamic Latency-Based Acquirer Routing',
        action: 'Implement automated route demotion when acquirer p99 latency exceeds 3000ms.',
        expectedOutcome: 'Prevents single-partner degradation from blocking customer checkouts.',
      }
    );
  } else if (dbFailureRegex.test(logs)) {
    severity = 'High';
    incidentTitle = 'Primary Ledger Database Connection Pool Saturation';
    severityReason = 'Database connection pool is congested, delaying transaction ledger updates.';
    incidentSummary = 'Primary ledger database connection pool saturation detected. Identify blocking queries and terminate idle transactions.';

    possibleRootCauses.push({
      id: 'HYP-01',
      hypothesis: 'Long-running query or batch job holding locks on ledger tables.',
      likelihood: 'High',
      rationale: 'Active pool connections reached max cap with queued threads.',
      validationSteps: ['Query pg_stat_activity for transactions in state idle in transaction'],
    });

    troubleshootingSteps.push(
      {
        stepNumber: 1,
        priority: 'P1',
        title: 'P1 Containment: Identify & Terminate Blocking Database PIDs',
        action: 'Run SELECT pg_cancel_backend(pid) on long-running queries identified in pg_stat_activity.',
        expectedOutcome: 'Frees locked connection slots and clears pool backlog.',
      },
      {
        stepNumber: 2,
        priority: 'P2',
        title: 'P2 Diagnostic: Inspect Active Connection Distribution by Application Service',
        action: 'Group active connections by client_addr and application_name in pg_stat_activity.',
        expectedOutcome: 'Identifies which microservice exhausted the connection pool.',
      },
      {
        stepNumber: 3,
        priority: 'P3',
        title: 'P3 Remediation: Scale HikariCP Connection Pool Max Limits',
        action: 'Increase max-pool-size on the primary transaction ledger service to accommodate spike.',
        expectedOutcome: 'Eliminates connection acquisition timeouts.',
      },
      {
        stepNumber: 4,
        priority: 'P4',
        title: 'P4 Prevention: Mandate Strict Statement Timeouts on All Ledger Queries',
        action: 'Configure statement_timeout=5000 in PostgreSQL connection string to prevent run-away queries.',
        expectedOutcome: 'Prevents rogue queries from exhausting connection pools.',
      }
    );
  } else {
    severity = warningCount > 0 ? 'Low' : 'Low';
    incidentTitle = warningCount > 0 ? 'Operational Performance Warning Detected' : 'Healthy Telemetry Stream - Normal Baseline';
    severityReason = warningCount > 0
      ? 'A single latency or threshold warning was detected. Transaction processing remains normal with zero customer disruption.'
      : 'No exceptions or fatal errors were found in the provided log stream.';
    incidentSummary = warningCount > 0
      ? 'Single operational telemetry warning detected without cascading failure.'
      : 'All monitored payment and authorization services operating within nominal SLA baseline.';

    possibleRootCauses.push({
      id: 'HYP-01',
      hypothesis: 'Transient provider latency spike or background worker delay.',
      likelihood: 'Low',
      rationale: 'Single warning occurred without subsequent cascade; fallback cache or poller succeeded.',
      validationSteps: ['Monitor next 15-minute telemetry window for recurrence'],
    });

    troubleshootingSteps.push(
      {
        stepNumber: 1,
        priority: 'P1',
        title: 'P1 Containment: Verify Active Transaction Throughput',
        action: 'Confirm real-time authorization success rate remains above 99.5% on live dashboard.',
        expectedOutcome: 'Validates that customer transactions are uninterrupted.',
      },
      {
        stepNumber: 2,
        priority: 'P2',
        title: 'P2 Diagnostic: Review Service Latency Telemetry Histogram',
        action: 'Examine p95 and p99 latency graphs for the affected service over the past 2 hours.',
        expectedOutcome: 'Determines if the warning was an isolated anomaly or an emerging trend.',
      },
      {
        stepNumber: 3,
        priority: 'P3',
        title: 'P3 Remediation: Set Up Automated Recurrence Alert Filter',
        action: 'Configure alert rule to trigger only if 3 or more similar warnings occur within a 10-minute window.',
        expectedOutcome: 'Suppresses noise while preserving early detection capability.',
      },
      {
        stepNumber: 4,
        priority: 'P4',
        title: 'P4 Prevention: Schedule Standard Sprint Maintenance Review',
        action: 'Add warning pattern review to the weekly TechOps backlog refinement meeting.',
        expectedOutcome: 'Proactive maintenance before any SLA impact.',
      }
    );
  }

  // Escalation guidance
  let escalation: RuleBasedAnalysis['escalation'];
  if ((severity as string) === 'Critical') {
    escalation = {
      shouldEscalate: true,
      targetTier: 'L3',
      triggerCondition: 'P1 Critical authorization blackout: expired signing key, tripped circuit breaker, or 100% checkout failure.',
      onCallTeam: 'Core Payments SRE, Cryptography & Security Architecture, VP of TechOps',
      slaResponseTime: '< 15 Minutes (P1 Critical Outage)',
      escalationChecklist: [
        'Open incident war room on Slack #incident-p1-critical',
        'Page L3 Payment Architect and Executive On-Call via PagerDuty',
        'Engage emergency key hot-swap in AWS KMS / HSM vault',
        'Post incident holding notice to Customer & Merchant Status Page',
        'Verify circuit breaker transition to HALF-OPEN after key rotation',
      ],
    };
  } else if (severity === 'High') {
    escalation = {
      shouldEscalate: true,
      targetTier: 'L2',
      triggerCondition: 'P2 High severity degradation: token cache desync, 403 Forbidden surge (>30%), or upstream gateway timeout.',
      onCallTeam: 'Payment Operations & Auth Infrastructure Tier 2',
      slaResponseTime: '< 30 Minutes (P2 High Degradation)',
      escalationChecklist: [
        'Drain traffic from desynchronized auth cache node auth-cache-02',
        'Inspect Redis replication offsets and verify master-replica consistency',
        'Audit webhook and token failure trends in Datadog/Grafana',
        'Force token refresh for affected merchant credentials',
      ],
    };
  } else if (severity === 'Medium') {
    escalation = {
      shouldEscalate: true,
      targetTier: 'L2',
      triggerCondition: 'P3 Medium operational asynchrony: pre-auth hold approved but capture rejected, or unconfirmed merchant callback.',
      onCallTeam: 'Payment Settlement Ops & Merchant Reconciliation Triage',
      slaResponseTime: '< 45 Minutes (P3 Operational Asynchrony)',
      escalationChecklist: [
        'Confirm authoritative status with payment processor using auth_code / ref',
        'Prevent automated re-authorizations to protect customer credit line',
        'Reconcile order status in Order Management System without double-debiting',
        'Audit batch settlement payload fields for formatting discrepancies',
      ],
    };
  } else {
    escalation = {
      shouldEscalate: false,
      targetTier: 'L1',
      triggerCondition: 'P4 Low severity warning: deprecated authorization header handled by compatibility fallback layer.',
      onCallTeam: 'L1 TechOps Queue Triage & Developer Relations',
      slaResponseTime: '< 4 Hours (P4 Standard Review)',
      escalationChecklist: [
        'Log incident in TechOps shift handover log',
        'Verify fallback compatibility layer metrics remain nominal with zero drops',
        'Send standard deprecation notice to merchant technical contacts',
      ],
    };
  }

  return {
    analysisMode: 'rule-based',
    modeLabel: 'Deterministic Rule-Based Engine (Fallback / Rule-Based Mode)',
    incidentId,
    incidentTitle,
    generatedAt: new Date().toISOString(),
    severity,
    severityReason,
    summary: incidentSummary || `${incidentTitle}. Analyzed ${totalLines} log lines. Telemetry triage completed across P1-P4 priority criteria.`,
    totalLinesParsed: totalLines,
    errorCount,
    warningCount,
    affectedServices: Array.from(servicesSet),
    timeWindow: {
      start: timeStart,
      end: timeEnd,
      duration,
    },
    repeatedErrors,
    confirmedEvidence: evidenceList,
    possibleRootCauses,
    troubleshootingSteps,
    escalation,
  };
}

// POST /api/analyze endpoint
app.post('/api/analyze', async (req, res) => {
  try {
    const { logs, forceRuleBased } = req.body as AnalysisPayload;

    if (!logs || typeof logs !== 'string' || logs.trim().length === 0) {
      return res.status(400).json({
        error: 'Empty log input. Please paste log text or upload a valid .txt or .log file.',
      });
    }

    if (logs.length > 3_000_000) {
      return res.status(400).json({
        error: 'Log file size exceeds maximum allowed limit (3MB). Please truncate to relevant incident timeframe.',
      });
    }

    // If client requested rule-based, or no Gemini API key configured, use rule-based analyzer
    if (forceRuleBased || !aiClient) {
      const result = runRuleBasedAnalysis(logs);
      result.modeLabel = !aiClient
        ? 'Rule-Based Engine (Gemini API key not configured in environment)'
        : 'Rule-Based Engine (User selected deterministic mode)';
      return res.json(result);
    }

    // Call Gemini API
    try {
      const truncatedLogsForAI = logs.slice(0, 150_000); // safe context window limit
      const prompt = `You are an elite Fintech Technology Operations & SRE Incident Commander analyzing simulated application, authentication, and payment gateway logs.

CURRENT CASE STUDY FOCUS:
"Payment Authorization & Auth Token Triage (P1-P4 Incidents)"
Business Problem:
Fintech payment gateways rely on multi-tier authorization workflows: cryptographic token validation (RS256 JWTs), 3DSecure cardholder authentication, and distributed OAuth session caches. Incidents span four operational priority levels:
- P1 (Critical Outage / Containment): Global authorization blackouts, signing key expiry, circuit breaker trips, 100% checkout stoppage.
- P2 (High Degradation / Diagnostic): Distributed token cache desyncs, scope drift (403 Forbidden), elevated failure surges (e.g. >30%).
- P3 (Medium Asynchrony / Remediation): Pre-auth hold approved on card line vs. stale/unmatched capture rejection (state mismatch).
- P4 (Low Warning / Prevention): Deprecated authorization headers handled by compatibility fallbacks, zero transaction drops.

CRITICAL SRE ACCURACY & RECOVERY RULES:
1. SEPARATE CONFIRMED EVIDENCE FROM POSSIBLE ROOT CAUSES. Never present assumptions or hypotheses as confirmed facts.
2. CONFIRMED EVIDENCE: Must be DIRECTLY OBSERVABLE in the logs (e.g. key expiry, 401 Unauthorized, circuit breaker OPEN, 403 Forbidden, 34% surge, pre-auth approved ref, stale capture, or deprecation warnings).
3. DO NOT SPECULATE OR MAKE FALSE ACCUSATIONS: Do NOT claim that the customer was charged twice, money was lost, or the order was definitely affected unless the logs prove it. Distinguish confirmed evidence from hypotheses and explicitly identify any missing information.
4. ASSIGN AN APPROPRIATE SEVERITY: Critical (P1), High (P2), Medium (P3), or Low (P4) with a clear, realistic operational reason.
5. MANDATORY 4-TIER TROUBLESHOOTING PLAN: Return prioritized troubleshooting steps utilizing the following priority labels:
   - 'P1': Containment actions (halt customer impact, hot-swap keys, drain bad nodes, prevent duplicate charges)
   - 'P2': Diagnostic actions (inspect replication offsets, verify JWKS propagation, audit payloads)
   - 'P3': Remediation actions (re-issue tokens, re-submit captures, reset circuit breakers)
   - 'P4': Prevention / Hardening actions (automated expiry alerts, drift alarms, deprecation milestones)
6. ESCALATION GUIDANCE: Explain when to escalate to L1, L2, or L3, including SLA response times and an actionable checklist.
7. Return your response ONLY as valid JSON conforming strictly to the requested schema.

LOGS TO ANALYZE:
\`\`\`
${truncatedLogsForAI}
\`\`\``;

      const aiResponse = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              incidentTitle: { type: Type.STRING },
              severity: {
                type: Type.STRING,
                description: 'Must be one of: Critical, High, Medium, Low',
              },
              severityReason: { type: Type.STRING },
              summary: { type: Type.STRING },
              affectedServices: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              repeatedErrors: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    signature: { type: Type.STRING },
                    count: { type: Type.INTEGER },
                    sampleMessage: { type: Type.STRING },
                    firstSeen: { type: Type.STRING },
                    lastSeen: { type: Type.STRING },
                    affectedServices: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                  },
                  required: ['signature', 'count', 'sampleMessage', 'affectedServices'],
                },
              },
              confirmedEvidence: {
                type: Type.ARRAY,
                description: 'Directly verified facts visible in logs. Never include assumptions here.',
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    category: { type: Type.STRING },
                    description: { type: Type.STRING },
                    rawExtract: { type: Type.STRING },
                    dataPoints: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                  },
                  required: ['id', 'category', 'description', 'rawExtract', 'dataPoints'],
                },
              },
              possibleRootCauses: {
                type: Type.ARRAY,
                description: 'Hypotheses that require validation. Never present as fact.',
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    hypothesis: { type: Type.STRING },
                    likelihood: { type: Type.STRING },
                    rationale: { type: Type.STRING },
                    validationSteps: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                  },
                  required: ['id', 'hypothesis', 'likelihood', 'rationale', 'validationSteps'],
                },
              },
              troubleshootingSteps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    stepNumber: { type: Type.INTEGER },
                    priority: {
                      type: Type.STRING,
                      description: 'Must be one of: P1, P2, P3, P4',
                    },
                    title: { type: Type.STRING },
                    action: { type: Type.STRING },
                    expectedOutcome: { type: Type.STRING },
                  },
                  required: ['stepNumber', 'priority', 'title', 'action', 'expectedOutcome'],
                },
              },
              escalation: {
                type: Type.OBJECT,
                properties: {
                  shouldEscalate: { type: Type.BOOLEAN },
                  targetTier: { type: Type.STRING },
                  triggerCondition: { type: Type.STRING },
                  onCallTeam: { type: Type.STRING },
                  slaResponseTime: { type: Type.STRING },
                  escalationChecklist: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                },
                required: ['shouldEscalate', 'targetTier', 'triggerCondition', 'onCallTeam', 'slaResponseTime', 'escalationChecklist'],
              },
            },
            required: [
              'incidentTitle',
              'severity',
              'severityReason',
              'summary',
              'affectedServices',
              'repeatedErrors',
              'confirmedEvidence',
              'possibleRootCauses',
              'troubleshootingSteps',
              'escalation',
            ],
          },
        },
      });

      const responseText = aiResponse.text;
      if (!responseText) {
        throw new Error('Gemini API returned empty text');
      }

      const parsedAI = JSON.parse(responseText);

      // Merge metrics and lines parsed from baseline
      const baseline = runRuleBasedAnalysis(logs);
      const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);

      const combinedResult: RuleBasedAnalysis = {
        analysisMode: 'gemini-ai',
        modeLabel: 'Gemini 3.8 Flash AI Model (Live Cognitive Log Analysis)',
        incidentId: `INC-${dateStr}-${randomSuffix}`,
        incidentTitle: parsedAI.incidentTitle || baseline.incidentTitle,
        generatedAt: new Date().toISOString(),
        severity: ['Critical', 'High', 'Medium', 'Low'].includes(parsedAI.severity)
          ? parsedAI.severity
          : baseline.severity,
        severityReason: parsedAI.severityReason || baseline.severityReason,
        summary: parsedAI.summary || baseline.summary,
        totalLinesParsed: baseline.totalLinesParsed,
        errorCount: baseline.errorCount,
        warningCount: baseline.warningCount,
        affectedServices: parsedAI.affectedServices?.length
          ? parsedAI.affectedServices
          : baseline.affectedServices,
        timeWindow: baseline.timeWindow,
        repeatedErrors: parsedAI.repeatedErrors?.length
          ? parsedAI.repeatedErrors
          : baseline.repeatedErrors,
        confirmedEvidence: parsedAI.confirmedEvidence?.length
          ? parsedAI.confirmedEvidence
          : baseline.confirmedEvidence,
        possibleRootCauses: parsedAI.possibleRootCauses?.length
          ? parsedAI.possibleRootCauses
          : baseline.possibleRootCauses,
        troubleshootingSteps: parsedAI.troubleshootingSteps?.length
          ? parsedAI.troubleshootingSteps.map((s: any, idx: number) => ({
              stepNumber: typeof s.stepNumber === 'number' ? s.stepNumber : idx + 1,
              priority: ['P1', 'P2', 'P3', 'P4'].includes(s.priority) ? s.priority : 'P2',
              title: s.title || `Troubleshooting Step ${idx + 1}`,
              action: s.action || '',
              expectedOutcome: s.expectedOutcome || '',
            }))
          : baseline.troubleshootingSteps,
        escalation: parsedAI.escalation || baseline.escalation,
      };

      return res.json(combinedResult);
    } catch (apiError: any) {
      console.warn('Gemini API call failed, falling back to rule-based analysis:', apiError?.message || apiError);
      const fallbackResult = runRuleBasedAnalysis(logs);
      fallbackResult.analysisMode = 'rule-based';
      fallbackResult.modeLabel = `Rule-Based Fallback Engine (Gemini API unavailable: ${apiError?.message || 'Rate limit or network error'})`;
      return res.json(fallbackResult);
    }
  } catch (error: any) {
    console.error('Incident analyzer error:', error);
    return res.status(500).json({
      error: error?.message || 'Internal server error while analyzing application logs',
    });
  }
});

// Vite middleware for dev or static for prod
async function setupServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AI Incident Analyzer] Server listening on http://0.0.0.0:${PORT}`);
  });
}

setupServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
